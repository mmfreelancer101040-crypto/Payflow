# SwiftRemit - Professional Money Transfer Management System

SwiftRemit is a complete, enterprise-grade Money Transfer and Remittance Management Application built for money transfer agencies and financial service businesses.

It features complete transaction lifecycle tracking, dual-format receipt printing (POS Thermal 80mm & Standard A4), fiduciary pass-through vs business revenue separation, daily and monthly financial reports, end-of-day cash reconciliation, expense tracking, audit logs, multi-currency support, full bilingual localization (English & Myanmar / Burmese), and a built-in automated financial calculations test suite.

---

## 🌟 Key Features

### 1. Executive Dashboard
- **Real-Time KPIs**: Total transfers count, transfer volume, service fee income, gross money received, money paid out, and pending obligations.
- **Cash in Drawer Display**: Live counter balance tracking opening float plus inflows minus outflows.
- **Monthly Overview**: Month-to-date volume and service fees with previous month comparative trends.
- **Fiduciary Accounting Banner**: Clear guidance distinguishing customer pass-through funds from company commission income.

### 2. Customer & Money Transfer Records
- **Automatic ID Generator**: Creates unique standard transaction IDs (e.g. `TRF-20261013-0001`).
- **Sender & Receiver Profiles**: Names, verified phone numbers, branch locations, and pickup points.
- **Multi-Currency & Forex**: Support for MMK, USD, THB, SGD, and MYR with live exchange rate conversion.
- **Flexible Fee Modes**: 
  - *Sender pays fee on top* (`Total Collected = Send Amount + Fee`)
  - *Deduct fee from send amount* (`Payout = (Send Amount - Fee) * Rate`)
- **Diverse Payment Channels**: Cash, KBZPay (KPay), WavePay, KBZ Bank, AYA Bank, CB Bank, and external bank transfers.
- **Status Lifecycle**: `Pending` ➔ `Processing` ➔ `Completed` ➔ `Cancelled` ➔ `Refunded`.
- **Search & Multi-Filters**: Instant search by transaction ID, customer name, phone, destination, payment method, date, or status.
- **Exporting**: 1-click CSV and Excel export.

### 3. Dual-Format Receipt Printing
- **POS Thermal (80mm)**: Compact receipt slip optimized for thermal counter printers with barcodes, verification references, NRC notices, and teller signatures.
- **Standard A4 Formal Voucher**: Full corporate voucher with company branding, tax registration, license credentials, itemized fee breakdown, and customer pickup instructions.
- **Copy Toggles**: Instant switch between **Customer Copy** and **Office Copy**.

### 4. Dedicated Financial Records (Zero Double-Counting)
- **Fiduciary Invariant**: Remittance principal is fiduciary custody, not business profit.
- **Revenue Recognition**: Business income is recognized strictly as earned service fees.
- **Comprehensive Ledger**: View combined ledger flows across transfers, operating expenses, and cash movements.

### 5. Daily Financial Summary
- Automated daily closing report for any chosen date.
- Opening cash balance, cash received, cash disbursed, service fees earned, business expenses, and daily net profit.
- Reconciles system-expected cash balance with actual physical counted cash, flagging variances (Balanced, Surplus, Shortage).
- Printable daily audit report and CSV export.

### 6. Monthly Financial Summary
- Monthly performance breakdown with Month-over-Month (MoM) growth percentages.
- Calendar breakdown table detailing daily volumes, fees, expenses, and net profit.
- Printable monthly financial statement.

### 7. Operating Expenses & Cash Management
- Categorized business costs: Rent, Staff Salaries, Electricity, Internet/Phone, Transportation, Office Supplies, Refreshments, and Maintenance.
- Cash movements: Cash deposits into corporate bank accounts, bank withdrawals into counter float, and owner capital adjustments.

### 8. End-of-Day Cash Reconciliation
- Daily cash close tool calculating expected counter cash.
- Physical cash verification with built-in **Myanmar Kyat Banknote Counter** (10,000, 5,000, 1,000, 500, 200, 100 Ks).
- Instant variance detection: Perfect Match, Surplus, or Shortage.

### 9. User Roles & Immutable Audit Trail
- **Manager (Admin)**: Full administrative permissions, edit privileges, reversal approvals, user management, and database restore.
- **Teller (Staff)**: Counter operations, transfer creation, payout execution, receipt printing, and daily closing.
- **Traceability**: Financial transactions are never permanently deleted without an audit trace; cancellations and refunds require explicit, documented reasons.
- **Audit Logs**: Immutable log recording every creation, modification, login, and reversal.

### 10. Data Backup & Restore
- 1-click **Export Backup (JSON)** downloading all transfers, expenses, ledgers, profiles, and audit records.
- 1-click **Restore Backup (JSON)** restoring state safely.
- Reset to pristine demo data for onboarding and testing.

### 11. Automated Test Suite
- Built-in runner testing decimal-safe arithmetic (`0.1 + 0.2 === 0.3`), pass-through vs revenue separation, multi-currency conversion, status exclusions, net profit calculations, and cash drawer equations.

### 12. Bilingual Interface
- Complete English and **Myanmar (မြန်မာဘာသာ)** language options.

---

## 🚀 Setup & Local Execution

### Prerequisites
- Node.js 18+ or 20+
- npm or yarn

### Installation
```bash
# Clone the repository
git clone <repository_url>
cd swiftremit

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will run locally on `http://localhost:3000`.

### Production Build
```bash
# Build production bundle
npm run build

# Preview build locally
npm run preview
```

---

## 🛡️ Default Accounts for Testing

| Account Role | Operator Name | Email | Default Password |
|---|---|---|---|
| **Manager (Admin)** | Daw Khin Sandar (Manager) | `admin@swiftremit.com` | `admin123` |
| **Teller (Staff)** | Ko Min Thura (Teller) | `staff@swiftremit.com` | `staff123` |

*You can switch between operators anytime using the user badge in the top right header.*

---

## ⚖️ Regulatory & Compliance Notice
This software is intended as an operational management and recordkeeping tool. Operation of a commercial money transfer or remittance service requires valid licenses, AML/KYC procedures, and adherence to relevant financial regulations in your operating jurisdiction.

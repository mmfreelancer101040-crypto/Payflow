import React, { useState, useEffect, useMemo } from 'react';
import { 
  MoneyTransfer, 
  BusinessExpense, 
  CashMovement, 
  CashReconciliation, 
  AuditLog, 
  User, 
  BusinessProfile, 
  Currency 
} from './types';
import { Language, translations } from './utils/i18n';
import { StorageService } from './utils/storage';
import { 
  generateDailySummary, 
  generateMonthlySummary, 
  calculateCurrentCashDrawer 
} from './utils/financialCalculations';

// Components
import { Header } from './components/Header';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { TransfersView } from './components/TransfersView';
import { FinancialRecordsView } from './components/FinancialRecordsView';
import { DailySummaryView } from './components/DailySummaryView';
import { MonthlySummaryView } from './components/MonthlySummaryView';
import { ExpensesCashView } from './components/ExpensesCashView';
import { CashReconciliationView } from './components/CashReconciliationView';
import { AuditLogsView } from './components/AuditLogsView';
import { SettingsUsersView } from './components/SettingsUsersView';
import { TestSuiteView } from './components/TestSuiteView';

// Modals
import { TransferModal } from './components/TransferModal';
import { ReceiptModal } from './components/ReceiptModal';
import { CancelRefundModal } from './components/CancelRefundModal';
import { TransferDetailsModal } from './components/TransferDetailsModal';
import { LoginModal } from './components/LoginModal';

export default function App() {
  // Global App States
  const [language, setLanguage] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isSidebarMobileOpen, setIsSidebarMobileOpen] = useState(false);

  // Database Records
  const [transfers, setTransfers] = useState<MoneyTransfer[]>(() => StorageService.getTransfers());
  const [expenses, setExpenses] = useState<BusinessExpense[]>(() => StorageService.getExpenses());
  const [cashMovements, setCashMovements] = useState<CashMovement[]>(() => StorageService.getCashMovements());
  const [reconciliations, setReconciliations] = useState<CashReconciliation[]>(() => StorageService.getReconciliations());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => StorageService.getAuditLogs());
  const [users, setUsers] = useState<User[]>(() => StorageService.getUsers());
  const [currentUser, setCurrentUser] = useState<User>(() => StorageService.getCurrentUser());
  const [profile, setProfile] = useState<BusinessProfile>(() => StorageService.getBusinessProfile());
  const [currencies, setCurrencies] = useState<Currency[]>(() => StorageService.getCurrencies());
  const [openingCash, setOpeningCash] = useState<number>(() => StorageService.getOpeningCash());

  // Modal Control States
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [editingTransfer, setEditingTransfer] = useState<MoneyTransfer | null>(null);

  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [selectedReceiptTransfer, setSelectedReceiptTransfer] = useState<MoneyTransfer | null>(null);

  const [isCancelRefundModalOpen, setIsCancelRefundModalOpen] = useState(false);
  const [reversalTransfer, setReversalTransfer] = useState<MoneyTransfer | null>(null);
  const [reversalMode, setReversalMode] = useState<'cancel' | 'refund'>('cancel');

  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [detailTransfer, setDetailTransfer] = useState<MoneyTransfer | null>(null);

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Sync state helpers
  const refreshDatabaseState = () => {
    setTransfers(StorageService.getTransfers());
    setExpenses(StorageService.getExpenses());
    setCashMovements(StorageService.getCashMovements());
    setReconciliations(StorageService.getReconciliations());
    setAuditLogs(StorageService.getAuditLogs());
    setUsers(StorageService.getUsers());
    setCurrentUser(StorageService.getCurrentUser());
    setProfile(StorageService.getBusinessProfile());
    setCurrencies(StorageService.getCurrencies());
    setOpeningCash(StorageService.getOpeningCash());
  };

  // Financial aggregates
  const todayStr = '2026-10-13';
  const monthStr = '2026-10';

  const todaySummary = useMemo(() => {
    return generateDailySummary(
      todayStr,
      transfers,
      expenses,
      cashMovements,
      reconciliations,
      openingCash
    );
  }, [transfers, expenses, cashMovements, reconciliations, openingCash]);

  const monthSummary = useMemo(() => {
    return generateMonthlySummary(monthStr, transfers, expenses);
  }, [transfers, expenses]);

  const cashInDrawer = useMemo(() => {
    return calculateCurrentCashDrawer(openingCash, transfers, expenses, cashMovements);
  }, [openingCash, transfers, expenses, cashMovements]);

  // Handler: Save or Update Transfer
  const handleSaveTransfer = (transferData: MoneyTransfer, editReason?: string) => {
    if (editingTransfer) {
      StorageService.updateTransfer(transferData, currentUser, editReason);
    } else {
      StorageService.addTransfer(transferData, currentUser);
      // Auto open receipt for the new transfer
      setSelectedReceiptTransfer(transferData);
      setIsReceiptModalOpen(true);
    }
    refreshDatabaseState();
    setEditingTransfer(null);
  };

  // Handler: Quick Complete
  const handleQuickComplete = (id: string) => {
    const item = transfers.find(t => t.id === id);
    if (!item) return;

    const updated: MoneyTransfer = {
      ...item,
      status: 'completed',
      updatedAt: new Date().toISOString(),
      updatedByStaffName: currentUser.name,
    };
    StorageService.updateTransfer(updated, currentUser, 'Marked as completed payout to receiver');
    refreshDatabaseState();
  };

  // Handler: Confirm Cancellation
  const handleConfirmCancel = (id: string, reason: string) => {
    StorageService.cancelTransfer(id, reason, currentUser);
    refreshDatabaseState();
    setIsCancelRefundModalOpen(false);
  };

  // Handler: Confirm Refund
  const handleConfirmRefund = (id: string, refundAmount: number, retainedFee: number, reason: string) => {
    StorageService.refundTransfer(id, refundAmount, retainedFee, reason, currentUser);
    refreshDatabaseState();
    setIsCancelRefundModalOpen(false);
  };

  // Handler: Add Expense
  const handleAddExpense = (expense: BusinessExpense) => {
    StorageService.addExpense(expense, currentUser);
    refreshDatabaseState();
  };

  // Handler: Add Cash Movement
  const handleAddMovement = (movement: CashMovement) => {
    StorageService.addCashMovement(movement, currentUser);
    refreshDatabaseState();
  };

  // Handler: Save Daily Cash Reconciliation
  const handleSaveReconciliation = (rec: CashReconciliation) => {
    StorageService.addReconciliation(rec, currentUser);
    refreshDatabaseState();
  };

  // Handler: Profile & Settings
  const handleSaveProfile = (updatedProfile: BusinessProfile) => {
    StorageService.saveBusinessProfile(updatedProfile);
    setProfile(updatedProfile);
  };

  const handleSaveUsers = (updatedUsers: User[]) => {
    StorageService.saveAllUsers(updatedUsers);
    setUsers(updatedUsers);
  };

  const handleUpdateOpeningCash = (val: number) => {
    StorageService.setOpeningCash(val);
    setOpeningCash(val);
  };

  const handleSwitchUser = (user: User) => {
    StorageService.setCurrentUser(user);
    setCurrentUser(user);
    StorageService.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      action: 'LOGIN',
      entityType: 'auth',
      entityId: user.id,
      details: `Operator switched to ${user.name} (${user.role})`,
    });
    setAuditLogs(StorageService.getAuditLogs());
  };

  const handleRestoreData = (jsonStr: string): boolean => {
    const ok = StorageService.importFullBackup(jsonStr, currentUser);
    if (ok) refreshDatabaseState();
    return ok;
  };

  const handleResetData = () => {
    StorageService.resetToDemoData(currentUser);
    refreshDatabaseState();
  };

  // Quick Action Helpers
  const openNewTransfer = () => {
    setEditingTransfer(null);
    setIsTransferModalOpen(true);
  };

  const openEditTransfer = (t: MoneyTransfer) => {
    setEditingTransfer(t);
    setIsTransferModalOpen(true);
  };

  const openPrintReceipt = (t: MoneyTransfer) => {
    setSelectedReceiptTransfer(t);
    setIsReceiptModalOpen(true);
  };

  const openCancelTransfer = (t: MoneyTransfer) => {
    setReversalTransfer(t);
    setReversalMode('cancel');
    setIsCancelRefundModalOpen(true);
  };

  const openRefundTransfer = (t: MoneyTransfer) => {
    setReversalTransfer(t);
    setReversalMode('refund');
    setIsCancelRefundModalOpen(true);
  };

  const openViewDetails = (t: MoneyTransfer) => {
    setDetailTransfer(t);
    setIsDetailsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* 3-Zone Clean Header */}
      <Header
        currentUser={currentUser}
        profile={profile}
        language={language}
        onLanguageChange={setLanguage}
        onOpenNewTransfer={openNewTransfer}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onToggleSidebar={() => setIsSidebarMobileOpen(!isSidebarMobileOpen)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          language={language}
          currentUser={currentUser}
          cashInDrawer={cashInDrawer}
          isOpenMobile={isSidebarMobileOpen}
          onCloseMobile={() => setIsSidebarMobileOpen(false)}
        />

        {/* Dynamic Content Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              todaySummary={todaySummary}
              monthSummary={monthSummary}
              recentTransfers={transfers}
              cashInDrawer={cashInDrawer}
              currentUser={currentUser}
              language={language}
              onOpenNewTransfer={openNewTransfer}
              onOpenAddExpense={() => setActiveTab('expenses')}
              onNavigateToTab={setActiveTab}
              onPrintTransfer={openPrintReceipt}
              onViewTransferDetails={openViewDetails}
            />
          )}

          {activeTab === 'transfers' && (
            <TransfersView
              transfers={transfers}
              currentUser={currentUser}
              language={language}
              onOpenNewTransfer={openNewTransfer}
              onEditTransfer={openEditTransfer}
              onPrintTransfer={openPrintReceipt}
              onCancelTransfer={openCancelTransfer}
              onRefundTransfer={openRefundTransfer}
              onQuickComplete={handleQuickComplete}
              onViewDetails={openViewDetails}
            />
          )}

          {activeTab === 'financial_records' && (
            <FinancialRecordsView
              transfers={transfers}
              expenses={expenses}
              cashMovements={cashMovements}
              reconciliations={reconciliations}
              openingCash={openingCash}
              cashInDrawer={cashInDrawer}
              currentUser={currentUser}
              language={language}
            />
          )}

          {activeTab === 'daily_summary' && (
            <DailySummaryView
              transfers={transfers}
              expenses={expenses}
              cashMovements={cashMovements}
              reconciliations={reconciliations}
              defaultOpeningCash={openingCash}
              profile={profile}
              currentUser={currentUser}
              language={language}
            />
          )}

          {activeTab === 'monthly_summary' && (
            <MonthlySummaryView
              transfers={transfers}
              expenses={expenses}
              profile={profile}
              currentUser={currentUser}
              language={language}
            />
          )}

          {activeTab === 'expenses' && (
            <ExpensesCashView
              expenses={expenses}
              cashMovements={cashMovements}
              currentUser={currentUser}
              language={language}
              onAddExpense={handleAddExpense}
              onAddMovement={handleAddMovement}
            />
          )}

          {activeTab === 'reconciliation' && (
            <CashReconciliationView
              transfers={transfers}
              expenses={expenses}
              cashMovements={cashMovements}
              reconciliations={reconciliations}
              openingCash={openingCash}
              currentUser={currentUser}
              language={language}
              onSaveReconciliation={handleSaveReconciliation}
            />
          )}

          {activeTab === 'audit_logs' && (
            <AuditLogsView
              logs={auditLogs}
              currentUser={currentUser}
              language={language}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsUsersView
              profile={profile}
              users={users}
              currencies={currencies}
              openingCash={openingCash}
              currentUser={currentUser}
              language={language}
              onSaveProfile={handleSaveProfile}
              onSaveUsers={handleSaveUsers}
              onSaveCurrencies={setCurrencies}
              onUpdateOpeningCash={handleUpdateOpeningCash}
              onRestoreData={handleRestoreData}
              onResetData={handleResetData}
            />
          )}

          {activeTab === 'test_suite' && (
            <TestSuiteView
              language={language}
            />
          )}
        </main>

      </div>

      {/* Floating or Overlay Modals */}
      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => {
          setIsTransferModalOpen(false);
          setEditingTransfer(null);
        }}
        onSave={handleSaveTransfer}
        currentUser={currentUser}
        editingTransfer={editingTransfer}
        currencies={currencies}
        language={language}
      />

      <ReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => {
          setIsReceiptModalOpen(false);
          setSelectedReceiptTransfer(null);
        }}
        transfer={selectedReceiptTransfer}
        profile={profile}
        language={language}
      />

      <CancelRefundModal
        isOpen={isCancelRefundModalOpen}
        onClose={() => {
          setIsCancelRefundModalOpen(false);
          setReversalTransfer(null);
        }}
        transfer={reversalTransfer}
        mode={reversalMode}
        currentUser={currentUser}
        language={language}
        onConfirmCancel={handleConfirmCancel}
        onConfirmRefund={handleConfirmRefund}
      />

      <TransferDetailsModal
        isOpen={isDetailsModalOpen}
        onClose={() => {
          setIsDetailsModalOpen(false);
          setDetailTransfer(null);
        }}
        transfer={detailTransfer}
        profile={profile}
        currentUser={currentUser}
        language={language}
        onPrint={openPrintReceipt}
        onEdit={openEditTransfer}
        onCancel={openCancelTransfer}
        onRefund={openRefundTransfer}
        onQuickComplete={handleQuickComplete}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        users={users}
        currentUser={currentUser}
        onSwitchUser={handleSwitchUser}
        language={language}
      />

    </div>
  );
}

import React, { useState } from 'react';
import { MoneyTransfer, User } from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, roundTo } from '../utils/financialCalculations';
import { AlertTriangle, X, Undo2, Ban } from 'lucide-react';

interface CancelRefundModalProps {
  isOpen: boolean;
  onClose: () => void;
  transfer: MoneyTransfer | null;
  mode: 'cancel' | 'refund';
  currentUser: User;
  language: Language;
  onConfirmCancel: (id: string, reason: string) => void;
  onConfirmRefund: (id: string, refundAmount: number, retainedFee: number, reason: string) => void;
}

export const CancelRefundModal: React.FC<CancelRefundModalProps> = ({
  isOpen,
  onClose,
  transfer,
  mode,
  currentUser,
  language,
  onConfirmCancel,
  onConfirmRefund,
}) => {
  const t = translations[language];

  const [reason, setReason] = useState('');
  const [refundMode, setRefundMode] = useState<'full' | 'retained'>('full');

  if (!isOpen || !transfer) return null;

  const fullRefundAmount = transfer.totalCollectedFromSender;
  const netRefundWithoutFee = transfer.sendAmount;
  const retainedFeeAmount = transfer.serviceFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      alert('A valid reason is required for accounting audit compliance.');
      return;
    }

    if (mode === 'cancel') {
      onConfirmCancel(transfer.id, reason.trim());
    } else {
      const refundAmt = refundMode === 'full' ? fullRefundAmount : netRefundWithoutFee;
      const retainedFee = refundMode === 'full' ? 0 : retainedFeeAmount;
      onConfirmRefund(transfer.id, refundAmt, retainedFee, reason.trim());
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-6">
        
        {/* Header */}
        <div className={`flex items-center justify-between px-6 py-4 border-b ${
          mode === 'cancel' ? 'bg-rose-50/70 border-rose-200' : 'bg-amber-50/70 border-amber-200'
        }`}>
          <div className="flex items-center gap-2.5">
            {mode === 'cancel' ? (
              <Ban className="w-5 h-5 text-rose-600" />
            ) : (
              <Undo2 className="w-5 h-5 text-amber-600" />
            )}
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {mode === 'cancel' ? t.confirmCancelTransfer : t.confirmRefundTransfer}
              </h2>
              <div className="text-xs text-slate-500 font-mono">
                {transfer.id} · {transfer.senderName} ➔ {transfer.receiverName}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Summary Box */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Transfer Amount:</span>
              <span className="font-mono font-bold text-slate-800">
                {formatCurrency(transfer.sendAmount, transfer.sendCurrency)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Service Fee Collected:</span>
              <span className="font-mono text-slate-800">
                {formatCurrency(transfer.serviceFee, transfer.sendCurrency)}
              </span>
            </div>
            <div className="flex justify-between font-bold border-t border-slate-200 pt-1 text-slate-900">
              <span>Total Received from Customer:</span>
              <span className="font-mono">
                {formatCurrency(transfer.totalCollectedFromSender, transfer.sendCurrency)}
              </span>
            </div>
          </div>

          {/* Refund Options if Refund Mode */}
          {mode === 'refund' && (
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                Refund Method / Amount Returned:
              </label>
              
              <label className="flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors hover:bg-slate-50 border-slate-300">
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="refundOption"
                    checked={refundMode === 'full'}
                    onChange={() => setRefundMode('full')}
                    className="text-emerald-700 focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-800 block">Full Refund (100%)</span>
                    <span className="text-slate-500">Refund principal and return service fee</span>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold text-slate-900">
                  {formatCurrency(fullRefundAmount, transfer.sendCurrency)}
                </span>
              </label>

              <label className="flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors hover:bg-slate-50 border-slate-300">
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="refundOption"
                    checked={refundMode === 'retained'}
                    onChange={() => setRefundMode('retained')}
                    className="text-emerald-700 focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-800 block">Net Refund (Retain Service Fee)</span>
                    <span className="text-slate-500">Refund principal only; company keeps processing fee</span>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold text-slate-900">
                  {formatCurrency(netRefundWithoutFee, transfer.sendCurrency)}
                </span>
              </label>
            </div>
          )}

          {/* Mandatory Reason Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.reversalReasonPrompt} *
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Sender requested cancellation prior to receiver pickup due to incorrect phone number..."
              className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-400 focus:border-slate-500"
            />
          </div>

          <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-lg text-[11px] text-slate-600">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
            <span>
              This reversal will be logged in the permanent audit trail under operator <strong>{currentUser.name}</strong>.
            </span>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
            >
              {t.close}
            </button>
            <button
              type="submit"
              className={`px-4 py-2 text-xs font-bold text-white rounded-lg shadow-xs cursor-pointer ${
                mode === 'cancel'
                  ? 'bg-rose-700 hover:bg-rose-800'
                  : 'bg-amber-700 hover:bg-amber-800'
              }`}
            >
              {mode === 'cancel' ? t.confirmCancelTransfer : t.confirmRefundTransfer}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { 
  MoneyTransfer, 
  BusinessExpense, 
  CashMovement, 
  CashReconciliation, 
  User 
} from '../types';
import { Language, translations } from '../utils/i18n';
import { 
  generateDailySummary, 
  formatCurrency, 
  formatNumberOnly, 
  roundTo 
} from '../utils/financialCalculations';
import { 
  Scale, 
  CheckCircle2, 
  AlertTriangle, 
  Calculator, 
  History, 
  Save, 
  DollarSign 
} from 'lucide-react';

interface CashReconciliationViewProps {
  transfers: MoneyTransfer[];
  expenses: BusinessExpense[];
  cashMovements: CashMovement[];
  reconciliations: CashReconciliation[];
  openingCash: number;
  currentUser: User;
  language: Language;
  onSaveReconciliation: (rec: CashReconciliation) => void;
}

export const CashReconciliationView: React.FC<CashReconciliationViewProps> = ({
  transfers,
  expenses,
  cashMovements,
  reconciliations,
  openingCash,
  currentUser,
  language,
  onSaveReconciliation,
}) => {
  const t = translations[language];

  const todayStr = '2026-10-13';
  const [reconDate, setReconDate] = useState<string>(todayStr);
  const [actualCountedInput, setActualCountedInput] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [useDenominations, setUseDenominations] = useState(false);

  // Common Myanmar Kyat denominations
  const [denominations, setDenominations] = useState<Record<string, number>>({
    '10000': 0,
    '5000': 0,
    '1000': 0,
    '500': 0,
    '200': 0,
    '100': 0,
    '50': 0,
  });

  // Calculate day summary for this date
  const daySummary = useMemo(() => {
    return generateDailySummary(
      reconDate,
      transfers,
      expenses,
      cashMovements,
      reconciliations,
      openingCash
    );
  }, [reconDate, transfers, expenses, cashMovements, reconciliations, openingCash]);

  // Denominations total calculation
  const denominationTotal = useMemo(() => {
    let sum = 0;
    for (const [denom, count] of Object.entries(denominations)) {
      sum += (parseInt(denom, 10) || 0) * (count || 0);
    }
    return sum;
  }, [denominations]);

  // Final actual physical cash value
  const actualCashValue = useDenominations ? denominationTotal : actualCountedInput;

  // Expected cash in drawer
  const expectedCash = daySummary.closingCashBalance;

  // Variance: actual - expected
  const variance = roundTo(actualCashValue - expectedCash);

  const handleDenomChange = (denomKey: string, val: number) => {
    setDenominations(prev => ({
      ...prev,
      [denomKey]: Math.max(0, val || 0)
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const record: CashReconciliation = {
      id: `REC-${reconDate.replace(/-/g, '')}`,
      date: reconDate,
      openingBalance: daySummary.openingCashBalance,
      cashReceivedToday: daySummary.totalMoneyReceived,
      cashPaidOutToday: daySummary.totalMoneyPaidOut,
      cashFeesReceivedToday: daySummary.totalServiceFeesEarned,
      cashExpensesPaidToday: daySummary.totalBusinessExpenses,
      bankDepositsFromCash: 0,
      bankWithdrawalsToCash: 0,
      expectedClosingCash: expectedCash,
      actualCountedCash: actualCashValue,
      variance,
      denominationBreakdown: useDenominations ? denominations : undefined,
      notes: notes.trim() || (variance === 0 ? 'Register balanced and closed' : `Discrepancy noted of ${variance} MMK`),
      reconciledByStaffName: currentUser.name,
      createdAt: new Date().toISOString(),
    };

    onSaveReconciliation(record);
    alert(`Daily cash reconciliation for ${reconDate} saved successfully!`);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.reconciliationTitle}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            End-of-day register audit: verify expected ledger balance against counted cash in drawer
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="date"
            value={reconDate}
            onChange={(e) => setReconDate(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden font-semibold text-slate-800"
          />
        </div>
      </div>

      {/* Main Reconciliation Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Financial Equation & Physical Count Form */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Expected Cash Drawer Calculation Formula */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-700" />
              1. System Cash Drawer Calculation ({reconDate})
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">{t.openingCashBalance}</span>
                <span className="font-mono-numbers text-base font-bold text-slate-900">
                  {formatCurrency(daySummary.openingCashBalance, 'MMK')}
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Total Cash Collected Today</span>
                <span className="font-mono-numbers text-base font-bold text-emerald-800">
                  +{formatCurrency(daySummary.totalMoneyReceived, 'MMK')}
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Total Cash Paid to Receivers</span>
                <span className="font-mono-numbers text-base font-bold text-slate-900">
                  -{formatCurrency(daySummary.totalMoneyPaidOut, 'MMK')}
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Cash Expenses Paid</span>
                <span className="font-mono-numbers text-base font-bold text-rose-700">
                  -{formatCurrency(daySummary.totalBusinessExpenses, 'MMK')}
                </span>
              </div>
            </div>

            {/* Expected Closing Cash Highlight */}
            <div className="p-4 bg-slate-900 text-white rounded-lg flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 block uppercase tracking-wider font-semibold">
                  {t.expectedClosingCash}
                </span>
                <span className="text-[11px] text-slate-400">
                  Mathematical balance expected in cash drawer
                </span>
              </div>
              <span className="font-mono-numbers text-2xl font-bold text-white">
                {formatCurrency(expectedCash, 'MMK')}
              </span>
            </div>
          </div>

          {/* Physical Cash Counting Section */}
          <form onSubmit={handleSave} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <Scale className="w-4 h-4 text-emerald-700" />
                2. Physical Cash Verification
              </h2>

              {/* Denomination Counter Toggle */}
              <button
                type="button"
                onClick={() => setUseDenominations(!useDenominations)}
                className="text-xs text-emerald-700 font-semibold hover:underline cursor-pointer"
              >
                {useDenominations ? 'Switch to Quick Total' : 'Use Currency Denomination Counter'}
              </button>
            </div>

            {/* Denominations Counter Mode */}
            {useDenominations ? (
              <div className="space-y-3 bg-slate-50/60 p-4 rounded-lg border border-slate-200">
                <span className="text-xs font-bold text-slate-700 block">
                  Myanmar Kyat Banknote Counts:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {Object.entries(denominations).map(([noteVal, count]) => (
                    <div key={noteVal}>
                      <label className="block text-[11px] font-mono text-slate-600 mb-1">
                        {noteVal} Ks Notes:
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={count || ''}
                        onChange={(e) => handleDenomChange(noteVal, parseInt(e.target.value, 10) || 0)}
                        className="w-full px-2.5 py-1 text-xs font-mono-numbers bg-white border border-slate-300 rounded-md focus:outline-hidden"
                        placeholder="0"
                      />
                    </div>
                  ))}
                </div>
                <div className="pt-2 text-right text-xs">
                  <span className="text-slate-500">Total Counted from Notes: </span>
                  <strong className="font-mono text-slate-900 text-sm">
                    {formatCurrency(denominationTotal, 'MMK')}
                  </strong>
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.actualCountedCash} (MMK) *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={actualCountedInput || ''}
                  onChange={(e) => setActualCountedInput(parseFloat(e.target.value) || 0)}
                  placeholder="Enter total counted physical cash in drawer..."
                  className="w-full px-3 py-2 text-sm font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            )}

            {/* Closing Notes */}
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Auditor & Reconciliation Notes
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Evening shift close, drawer checked by supervisor..."
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            {/* Save Button */}
            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{t.submitReconciliation}</span>
              </button>
            </div>
          </form>

        </div>

        {/* Right 1 Column: Instant Difference / Variance Visual Card */}
        <div className="space-y-6">
          
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              {t.cashVariance}
            </h2>

            <div className={`p-5 rounded-xl border flex flex-col items-center text-center space-y-2 ${
              variance === 0
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                : variance > 0
                ? 'bg-blue-50/70 border-blue-200 text-blue-900'
                : 'bg-rose-50/70 border-rose-200 text-rose-900'
            }`}>
              {variance === 0 ? (
                <CheckCircle2 className="w-10 h-10 text-emerald-600" />
              ) : (
                <AlertTriangle className={`w-10 h-10 ${variance > 0 ? 'text-blue-600' : 'text-rose-600'}`} />
              )}

              <div className="font-mono-numbers text-2xl font-bold">
                {variance >= 0 ? `+${formatCurrency(variance, 'MMK')}` : formatCurrency(variance, 'MMK')}
              </div>

              <div className="text-xs font-bold">
                {variance === 0 ? t.balanced : variance > 0 ? t.cashSurplus : t.cashShortage}
              </div>

              <p className="text-[11px] opacity-80 max-w-xs leading-relaxed">
                {variance === 0
                  ? 'Counted cash matches system records with 100% precision.'
                  : variance > 0
                  ? 'More cash was found in the register than recorded by the system.'
                  : 'Physical cash in drawer is less than recorded. Please check for unrecorded expenses or payouts.'}
              </p>
            </div>

            <div className="space-y-2 text-xs pt-2">
              <div className="flex justify-between text-slate-500">
                <span>System Expected:</span>
                <span className="font-mono font-bold text-slate-800">{formatCurrency(expectedCash, 'MMK')}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Actual Counted:</span>
                <span className="font-mono font-bold text-slate-800">{formatCurrency(actualCashValue, 'MMK')}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Staff Teller:</span>
                <span className="font-medium text-slate-800">{currentUser.name}</span>
              </div>
            </div>
          </div>

          {/* Historical Reconciliations Archive */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <History className="w-4 h-4 text-slate-500" />
              Recent Reconciliation History
            </h3>

            <div className="space-y-2.5">
              {reconciliations.slice(0, 5).map((rec) => (
                <div key={rec.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 font-mono">{rec.date}</span>
                    <span className={`font-mono font-bold text-[11px] ${
                      rec.variance === 0 ? 'text-emerald-700' : 'text-rose-700'
                    }`}>
                      {rec.variance === 0 ? 'Balanced (0)' : `Var: ${formatCurrency(rec.variance, 'MMK')}`}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Expected: {formatCurrency(rec.expectedClosingCash, 'MMK')} · Counted: {formatCurrency(rec.actualCountedCash, 'MMK')}
                  </div>
                  <div className="text-[10px] text-slate-400 italic">
                    Audited by {rec.reconciledByStaffName}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};

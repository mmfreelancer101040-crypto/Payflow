import React from 'react';
import { 
  DailySummaryData, 
  MonthlySummaryData, 
  MoneyTransfer, 
  User 
} from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly } from '../utils/financialCalculations';
import { 
  ArrowLeftRight, 
  TrendingUp, 
  DollarSign, 
  Wallet, 
  Clock, 
  ShieldCheck, 
  PlusCircle, 
  Receipt, 
  Scale, 
  FileText,
  Printer,
  ChevronRight,
  Info
} from 'lucide-react';

interface DashboardViewProps {
  todaySummary: DailySummaryData;
  monthSummary: MonthlySummaryData;
  recentTransfers: MoneyTransfer[];
  cashInDrawer: number;
  currentUser: User;
  language: Language;
  onOpenNewTransfer: () => void;
  onOpenAddExpense: () => void;
  onNavigateToTab: (tab: any) => void;
  onPrintTransfer: (t: MoneyTransfer) => void;
  onViewTransferDetails: (t: MoneyTransfer) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  todaySummary,
  monthSummary,
  recentTransfers,
  cashInDrawer,
  currentUser,
  language,
  onOpenNewTransfer,
  onOpenAddExpense,
  onNavigateToTab,
  onPrintTransfer,
  onViewTransferDetails,
}) => {
  const t = translations[language];

  return (
    <div className="space-y-6">
      
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.dashboard}
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
            <span>Branch Operations Overview</span>
            <span aria-hidden="true">·</span>
            <span>{new Date().toLocaleDateString(language === 'my' ? 'my-MM' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={onOpenNewTransfer}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.newTransfer}</span>
          </button>

          <button
            type="button"
            onClick={onOpenAddExpense}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer transition-colors"
          >
            <Receipt className="w-4 h-4 text-slate-500" />
            <span>{t.addExpense}</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateToTab('reconciliation')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer transition-colors"
          >
            <Scale className="w-4 h-4 text-emerald-700" />
            <span>{t.cashReconciliation}</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1: Today's Total Transfers Volume */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">{t.todayVolume}</span>
            <span className="font-mono text-xs text-slate-400">
              {todaySummary.totalTransfersCount} {t.transfers.toLowerCase()}
            </span>
          </div>
          <div className="font-mono-numbers text-xl font-bold text-slate-900">
            {formatCurrency(todaySummary.totalTransferVolume, 'MMK')}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-2">
            <span>Completed: <strong className="text-slate-800">{todaySummary.completedCount}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Pending: <strong className="text-amber-700">{todaySummary.pendingCount}</strong></span>
          </div>
        </div>

        {/* KPI 2: Service Fees Earned Today (Business Gross Income) */}
        <div className="bg-white p-4 rounded-xl border border-emerald-200/90 shadow-2xs bg-emerald-50/20">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium text-emerald-900 font-semibold">{t.todayServiceFees}</span>
            <TrendingUp className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="font-mono-numbers text-xl font-bold text-emerald-800">
            {formatCurrency(todaySummary.totalServiceFeesEarned, 'MMK')}
          </div>
          <div className="text-[11px] text-emerald-700 mt-2 font-medium">
            Recognized Business Commission
          </div>
        </div>

        {/* KPI 3: Daily Net Profit (Fees minus Expenses) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">{t.todayNetProfit}</span>
            <span className="text-[10px] text-slate-400">Fees - Expenses</span>
          </div>
          <div className={`font-mono-numbers text-xl font-bold ${
            todaySummary.netProfit >= 0 ? 'text-slate-900' : 'text-rose-700'
          }`}>
            {formatCurrency(todaySummary.netProfit, 'MMK')}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-2">
            <span>Expenses: <strong className="text-slate-700">{formatCurrency(todaySummary.totalBusinessExpenses, 'MMK')}</strong></span>
          </div>
        </div>

        {/* KPI 4: Cash Currently in Register */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">{t.cashOnHand}</span>
            <Wallet className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="font-mono-numbers text-xl font-bold text-slate-900">
            {formatCurrency(cashInDrawer, 'MMK')}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
            <span>Pending Payout:</span>
            <strong className="text-amber-700 font-mono">{formatCurrency(todaySummary.pendingPayoutLiabilities, 'MMK')}</strong>
          </div>
        </div>

      </div>

      {/* Secondary Flow & Monthly Overview Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Money In vs Money Out Breakdown */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Today's Inflow & Outflow
            </h2>
            <button
              type="button"
              onClick={() => onNavigateToTab('financial_records')}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-medium flex items-center gap-1"
            >
              <span>{t.financialRecords}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-1">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-500 block">{t.todayReceived}</span>
                <span className="text-[10px] text-slate-400">Total collected from senders</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-slate-900">
                {formatCurrency(todaySummary.totalMoneyReceived, 'MMK')}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-500 block">{t.todayPaidOut}</span>
                <span className="text-[10px] text-slate-400">Total disbursed to receivers</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-slate-900">
                {formatCurrency(todaySummary.totalMoneyPaidOut, 'MMK')}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-500 block">{t.todayPending}</span>
                <span className="text-[10px] text-amber-700">Awaiting receiver collection</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-amber-800">
                {formatCurrency(todaySummary.pendingPayoutLiabilities, 'MMK')}
              </span>
            </div>
          </div>
        </div>

        {/* Monthly Performance Summary */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Monthly Progress ({monthSummary.monthName})
            </h2>
            <button
              type="button"
              onClick={() => onNavigateToTab('monthly_summary')}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-medium flex items-center gap-1"
            >
              <span>{t.monthlySummary}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-1">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-500 block">{t.monthlyVolume}</span>
                <span className="text-[10px] text-slate-400">{monthSummary.totalTransfersCount} transfers</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-slate-900">
                {formatCurrency(monthSummary.totalTransferVolume, 'MMK')}
              </span>
            </div>

            <div className="p-3 bg-emerald-50/50 rounded-lg border border-emerald-200/80 flex justify-between items-center">
              <div>
                <span className="text-xs font-medium text-emerald-900 block">{t.monthlyFees}</span>
                <span className="text-[10px] text-emerald-700">Gross revenue</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-emerald-800">
                {formatCurrency(monthSummary.totalServiceFeesEarned, 'MMK')}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-500 block">Monthly Net Profit</span>
                <span className="text-[10px] text-slate-400">After all expenses</span>
              </div>
              <span className="font-mono-numbers text-sm font-bold text-slate-900">
                {formatCurrency(monthSummary.netProfit, 'MMK')}
              </span>
            </div>
          </div>
        </div>

        {/* Fiduciary Accounting Separation Guidance */}
        <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Info className="w-4 h-4 text-emerald-700" />
              <h3 className="text-xs font-bold text-slate-800">
                {t.fiduciaryNotice}
              </h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              {t.passThroughExpl}
            </p>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t.businessIncomeExpl}
            </p>
          </div>

          <div className="pt-4 border-t border-slate-200 mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>Decimal-Safe Precision</span>
            <span className="font-mono text-emerald-700 font-semibold">IEEE-754 Safe</span>
          </div>
        </div>

      </div>

      {/* Recent Transfers Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              {t.recentTransfers}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Latest transactions recorded across counters
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigateToTab('transfers')}
            className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>View All ({recentTransfers.length})</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/70 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">TXN ID</th>
                <th className="py-3 px-4">Date / Time</th>
                <th className="py-3 px-4">Sender</th>
                <th className="py-3 px-4">Receiver</th>
                <th className="py-3 px-4 text-right">Transfer Amount</th>
                <th className="py-3 px-4 text-right">Service Fee</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right no-print">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentTransfers.slice(0, 6).map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    <button
                      type="button"
                      onClick={() => onViewTransferDetails(item)}
                      className="hover:underline cursor-pointer text-left"
                    >
                      {item.id}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                    {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    <span className="block text-[10px] text-slate-400">{item.date.slice(0, 10)}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-800">{item.senderName}</div>
                    <div className="text-[10px] text-slate-400">{item.senderPhone} · {item.senderLocation}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-800">{item.receiverName}</div>
                    <div className="text-[10px] text-slate-400">{item.receiverPhone} · {item.receiverLocation}</div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                    {formatCurrency(item.sendAmount, item.sendCurrency)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-emerald-700 whitespace-nowrap font-medium">
                    +{formatCurrency(item.serviceFee, item.sendCurrency)}
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                      item.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : item.status === 'processing'
                        ? 'bg-blue-100 text-blue-800'
                        : item.status === 'refunded'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right no-print">
                    <button
                      type="button"
                      onClick={() => onPrintTransfer(item)}
                      title="Print Customer/Office Receipt"
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md cursor-pointer transition-colors"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

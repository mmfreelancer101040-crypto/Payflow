import React, { useState } from 'react';
import { 
  BusinessExpense, 
  CashMovement, 
  ExpenseCategory, 
  PaymentMethod, 
  CashMovementType, 
  User 
} from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly, roundTo } from '../utils/financialCalculations';
import { StorageService } from '../utils/storage';
import { 
  Receipt, 
  PlusCircle, 
  Layers, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Download, 
  X,
  PieChart
} from 'lucide-react';

interface ExpensesCashViewProps {
  expenses: BusinessExpense[];
  cashMovements: CashMovement[];
  currentUser: User;
  language: Language;
  onAddExpense: (expense: BusinessExpense) => void;
  onAddMovement: (movement: CashMovement) => void;
}

export const ExpensesCashView: React.FC<ExpensesCashViewProps> = ({
  expenses,
  cashMovements,
  currentUser,
  language,
  onAddExpense,
  onAddMovement,
}) => {
  const t = translations[language];

  // Modals state
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);

  // Expense form state
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>('office_supplies');
  const [expenseAmount, setExpenseAmount] = useState<number>(10000);
  const [expenseCurrency, setExpenseCurrency] = useState('MMK');
  const [expensePaymentMethod, setExpensePaymentMethod] = useState<PaymentMethod>('cash');
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseReceiptNo, setExpenseReceiptNo] = useState('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().slice(0, 10));

  // Cash movement form state
  const [movementType, setMovementType] = useState<CashMovementType>('bank_deposit');
  const [movementAmount, setMovementAmount] = useState<number>(500000);
  const [movementSource, setMovementSource] = useState('KBZ Bank Branch Account');
  const [movementRef, setMovementRef] = useState('');
  const [movementDesc, setMovementDesc] = useState('Branch cash deposited into corporate bank account');
  const [movementDate, setMovementDate] = useState(new Date().toISOString().slice(0, 10));

  // Filter state
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredExpenses = expenses.filter(e => {
    if (categoryFilter !== 'all' && e.category !== categoryFilter) return false;
    return true;
  });

  // Calculate expense category breakdown
  const categoryTotals: Record<string, number> = {};
  let totalExpensesSum = 0;
  for (const exp of expenses) {
    categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
    totalExpensesSum += exp.amount;
  }

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseDesc.trim()) {
      alert('Please enter a description for the expense.');
      return;
    }
    if (expenseAmount <= 0) {
      alert('Expense amount must be greater than zero.');
      return;
    }

    const newExpense: BusinessExpense = {
      id: StorageService.generateNewExpenseId(),
      date: `${expenseDate}T${new Date().toISOString().slice(11)}`,
      category: expenseCategory,
      amount: roundTo(expenseAmount),
      currency: expenseCurrency,
      paymentMethod: expensePaymentMethod,
      description: expenseDesc.trim(),
      receiptNumber: expenseReceiptNo.trim() || undefined,
      recordedByStaffName: currentUser.name,
      recordedByStaffId: currentUser.id,
      createdAt: new Date().toISOString(),
    };

    onAddExpense(newExpense);
    setIsExpenseModalOpen(false);
    setExpenseDesc('');
    setExpenseReceiptNo('');
  };

  const handleMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (movementAmount <= 0) {
      alert('Amount must be greater than zero.');
      return;
    }

    const newMovement: CashMovement = {
      id: `MOV-${Date.now()}`,
      date: `${movementDate}T${new Date().toISOString().slice(11)}`,
      type: movementType,
      amount: roundTo(movementAmount),
      currency: 'MMK',
      bankAccountOrSource: movementSource.trim(),
      referenceNumber: movementRef.trim() || undefined,
      description: movementDesc.trim(),
      recordedByStaffName: currentUser.name,
      createdAt: new Date().toISOString(),
    };

    onAddMovement(newMovement);
    setIsMovementModalOpen(false);
    setMovementRef('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.expenses}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Operational overhead tracking, rent, utilities, salaries, and bank cash transfers
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => setIsExpenseModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.addExpense}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsMovementModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer transition-colors"
          >
            <Layers className="w-4 h-4 text-slate-500" />
            <span>Bank / Float Movement</span>
          </button>
        </div>
      </div>

      {/* Expense Categories Breakdown Bar */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Operating Expenses by Category
          </h2>
          <span className="font-mono text-xs font-bold text-slate-900">
            Total: {formatCurrency(totalExpensesSum, 'MMK')}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {Object.entries(categoryTotals).map(([cat, amt]) => {
            const pct = totalExpensesSum > 0 ? Math.round((amt / totalExpensesSum) * 100) : 0;
            return (
              <div key={cat} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 uppercase block truncate">
                  {cat.replace('_', ' ')}
                </span>
                <span className="font-mono-numbers text-sm font-bold text-slate-900 block mt-0.5">
                  {formatCurrency(amt, 'MMK')}
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  {pct}% of operating costs
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expenses List & Filter */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        
        <div className="p-4 border-b border-slate-200 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800">Expense Records ({filteredExpenses.length})</span>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden"
            >
              <option value="all">All Expense Categories</option>
              <option value="rent">Rent</option>
              <option value="salaries">Salaries</option>
              <option value="electricity">Electricity</option>
              <option value="internet_phone">Internet & Phone</option>
              <option value="transportation">Transportation</option>
              <option value="office_supplies">Office Supplies</option>
              <option value="refreshments">Customer Refreshments</option>
              <option value="maintenance">Maintenance</option>
              <option value="miscellaneous">Miscellaneous</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/70 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Expense ID</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Method / Receipt No.</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Recorded By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredExpenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-800 whitespace-nowrap">
                    {exp.id}
                  </td>
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                    {exp.date.slice(0, 10)}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700 capitalize whitespace-nowrap">
                    {exp.category.replace('_', ' ')}
                  </td>
                  <td className="py-3 px-4 text-slate-800 font-medium max-w-sm truncate">
                    {exp.description}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    {exp.paymentMethod.toUpperCase()} {exp.receiptNumber ? `(${exp.receiptNumber})` : ''}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-700 whitespace-nowrap">
                    -{formatCurrency(exp.amount, exp.currency)}
                  </td>
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                    {exp.recordedByStaffName}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

      {/* Cash and Bank Movements (Deposits & Withdrawals) */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Cash Drawer & Bank Account Movements
          </h2>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Internal movements between cash register, corporate bank accounts, and float injections
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/70 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Movement Type</th>
                <th className="py-3 px-4">Account / Source</th>
                <th className="py-3 px-4">Description / Reference</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Staff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {cashMovements.map((m) => (
                <tr key={m.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap font-mono">
                    {m.date.slice(0, 10)}
                  </td>
                  <td className="py-3 px-4 font-semibold whitespace-nowrap">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] uppercase ${
                      m.type === 'bank_deposit'
                        ? 'bg-blue-100 text-blue-800'
                        : m.type === 'bank_withdrawal'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}>
                      {m.type.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-700 font-medium">
                    {m.bankAccountOrSource}
                  </td>
                  <td className="py-3 px-4 text-slate-600 max-w-sm truncate">
                    {m.description} {m.referenceNumber ? `[Ref: ${m.referenceNumber}]` : ''}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                    {formatCurrency(m.amount, m.currency)}
                  </td>
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                    {m.recordedByStaffName}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add Expense */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">{t.addExpense}</h3>
              <button
                type="button"
                onClick={() => setIsExpenseModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExpenseSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{t.date}</label>
                <input
                  type="date"
                  required
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{t.expenseCategory}</label>
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value as ExpenseCategory)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 capitalize"
                >
                  <option value="rent">Rent</option>
                  <option value="salaries">Salaries & Wages</option>
                  <option value="electricity">Electricity / Power</option>
                  <option value="internet_phone">Internet & Phone</option>
                  <option value="transportation">Transportation / Fuel</option>
                  <option value="office_supplies">Office Supplies / Paper</option>
                  <option value="refreshments">Lobby Refreshments / Water</option>
                  <option value="tax_fees">Licenses & Government Fees</option>
                  <option value="maintenance">Office Maintenance</option>
                  <option value="miscellaneous">Miscellaneous Costs</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{t.expenseAmount} (MMK) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 text-xs font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{t.paymentMethod}</label>
                <select
                  value={expensePaymentMethod}
                  onChange={(e) => setExpensePaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                >
                  <option value="cash">{t.cash}</option>
                  <option value="kbz_pay">{t.kbz_pay}</option>
                  <option value="wave_pay">{t.wave_pay}</option>
                  <option value="kbz_bank">{t.kbz_bank}</option>
                  <option value="bank_transfer">{t.bank_transfer}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{t.expenseDescription} *</label>
                <input
                  type="text"
                  required
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="e.g. Printer thermal receipt rolls and stationery"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Receipt / Invoice No. (Optional)</label>
                <input
                  type="text"
                  value={expenseReceiptNo}
                  onChange={(e) => setExpenseReceiptNo(e.target.value)}
                  placeholder="e.g. INV-9982"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer"
                >
                  Record Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Movement */}
      {isMovementModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">Record Cash / Bank Movement</h3>
              <button
                type="button"
                onClick={() => setIsMovementModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleMovementSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Movement Type</label>
                <select
                  value={movementType}
                  onChange={(e) => setMovementType(e.target.value as CashMovementType)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                >
                  <option value="bank_deposit">Cash Deposit to Bank (Reduces drawer, increases bank)</option>
                  <option value="bank_withdrawal">Bank Withdrawal to Cash (Increases drawer, reduces bank)</option>
                  <option value="owner_capital_in">Owner Float / Capital Injection (Increases drawer cash)</option>
                  <option value="owner_drawing">Owner Drawing / Cash Withdrawal (Reduces drawer cash)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Amount (MMK) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={movementAmount}
                  onChange={(e) => setMovementAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 text-xs font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Bank Account or Cash Source *</label>
                <input
                  type="text"
                  required
                  value={movementSource}
                  onChange={(e) => setMovementSource(e.target.value)}
                  placeholder="e.g. KBZ Bank Branch A/C # 1002938192"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Bank Slip / Reference No.</label>
                <input
                  type="text"
                  value={movementRef}
                  onChange={(e) => setMovementRef(e.target.value)}
                  placeholder="e.g. DEP-20261013-01"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
                <input
                  type="text"
                  value={movementDesc}
                  onChange={(e) => setMovementDesc(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsMovementModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer"
                >
                  Record Movement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

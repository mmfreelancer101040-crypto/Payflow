import React, { useState } from 'react';
import { 
  MoneyTransfer, 
  BusinessExpense, 
  CashMovement, 
  CashReconciliation, 
  User 
} from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly, roundTo } from '../utils/financialCalculations';
import { 
  BookOpen, 
  ShieldCheck, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Layers, 
  AlertCircle, 
  Download,
  Info,
  CheckCircle2
} from 'lucide-react';

interface FinancialRecordsViewProps {
  transfers: MoneyTransfer[];
  expenses: BusinessExpense[];
  cashMovements: CashMovement[];
  reconciliations: CashReconciliation[];
  openingCash: number;
  cashInDrawer: number;
  currentUser: User;
  language: Language;
}

export const FinancialRecordsView: React.FC<FinancialRecordsViewProps> = ({
  transfers,
  expenses,
  cashMovements,
  reconciliations,
  openingCash,
  cashInDrawer,
  currentUser,
  language,
}) => {
  const t = translations[language];
  const [activeLedgerTab, setActiveLedgerTab] = useState<'all' | 'passthrough' | 'revenue' | 'expenses' | 'cash_movements'>('all');

  // Aggregated totals across all records
  let totalGrossTransfersVolume = 0;
  let totalMoneyReceivedFromCustomers = 0;
  let totalMoneyPaidToReceivers = 0;
  let totalServiceFeesEarned = 0;
  let totalCancelledVolume = 0;
  let totalRefundedVolume = 0;
  let totalPendingLiabilities = 0;

  for (const item of transfers) {
    if (item.status === 'completed') {
      totalGrossTransfersVolume = roundTo(totalGrossTransfersVolume + item.sendAmount);
      totalMoneyReceivedFromCustomers = roundTo(totalMoneyReceivedFromCustomers + item.totalCollectedFromSender);
      totalMoneyPaidToReceivers = roundTo(totalMoneyPaidToReceivers + item.payoutAmount);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + item.serviceFee);
    } else if (item.status === 'pending' || item.status === 'processing') {
      totalGrossTransfersVolume = roundTo(totalGrossTransfersVolume + item.sendAmount);
      totalMoneyReceivedFromCustomers = roundTo(totalMoneyReceivedFromCustomers + item.totalCollectedFromSender);
      totalPendingLiabilities = roundTo(totalPendingLiabilities + item.payoutAmount);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + item.serviceFee);
    } else if (item.status === 'cancelled') {
      totalCancelledVolume = roundTo(totalCancelledVolume + item.sendAmount);
    } else if (item.status === 'refunded') {
      totalRefundedVolume = roundTo(totalRefundedVolume + (item.refundAmount || item.sendAmount));
      if (item.refundFeeRetained) {
        totalServiceFeesEarned = roundTo(totalServiceFeesEarned + item.refundFeeRetained);
      }
    }
  }

  const totalBusinessExpenses = roundTo(expenses.reduce((sum, e) => sum + e.amount, 0));
  const cumulativeNetProfit = roundTo(totalServiceFeesEarned - totalBusinessExpenses);

  // Bank Deposits & Withdrawals
  let totalBankDeposits = 0;
  let totalBankWithdrawals = 0;
  for (const m of cashMovements) {
    if (m.type === 'bank_deposit') totalBankDeposits = roundTo(totalBankDeposits + m.amount);
    if (m.type === 'bank_withdrawal') totalBankWithdrawals = roundTo(totalBankWithdrawals + m.amount);
  }

  // Combined ledger events
  const ledgerEntries = [
    ...transfers.map(t => ({
      id: t.id,
      date: t.date,
      type: 'transfer' as const,
      category: t.status === 'completed' ? 'Transfer Completed' : `Transfer ${t.status}`,
      description: `${t.senderName} ➔ ${t.receiverName} (${t.sendCurrency})`,
      inflow: t.status !== 'cancelled' ? t.totalCollectedFromSender : 0,
      outflow: t.status === 'completed' ? t.payoutAmount : 0,
      feeRevenue: t.status !== 'cancelled' ? (t.status === 'refunded' ? (t.refundFeeRetained || 0) : t.serviceFee) : 0,
      channel: t.paymentMethod,
      status: t.status,
    })),
    ...expenses.map(e => ({
      id: e.id,
      date: e.date,
      type: 'expense' as const,
      category: `Expense: ${e.category.toUpperCase()}`,
      description: e.description,
      inflow: 0,
      outflow: e.amount,
      feeRevenue: 0,
      channel: e.paymentMethod,
      status: 'completed',
    })),
    ...cashMovements.map(m => ({
      id: m.id,
      date: m.date,
      type: 'movement' as const,
      category: `Cash Movement: ${m.type}`,
      description: `${m.description} (${m.bankAccountOrSource})`,
      inflow: (m.type === 'bank_withdrawal' || m.type === 'owner_capital_in') ? m.amount : 0,
      outflow: (m.type === 'bank_deposit' || m.type === 'owner_drawing') ? m.amount : 0,
      feeRevenue: 0,
      channel: 'bank_transfer',
      status: 'completed',
    }))
  ].sort((a, b) => b.date.localeCompare(a.date));

  const filteredEntries = ledgerEntries.filter(e => {
    if (activeLedgerTab === 'passthrough') return e.type === 'transfer';
    if (activeLedgerTab === 'revenue') return e.type === 'transfer' && e.feeRevenue > 0;
    if (activeLedgerTab === 'expenses') return e.type === 'expense';
    if (activeLedgerTab === 'cash_movements') return e.type === 'movement';
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.financialRecords}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Fiduciary pass-through tracking, business revenue recognition, and ledger separation
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 text-emerald-800 rounded-md border border-emerald-200">
            Zero Double-Counting Architecture
          </span>
        </div>
      </div>

      {/* Financial Matrix Cards: Strict Accounting Distinction */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Pass-Through Volume */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            1. Total Money Received
          </span>
          <div className="font-mono-numbers text-xl font-bold text-slate-900">
            {formatCurrency(totalMoneyReceivedFromCustomers, 'MMK')}
          </div>
          <p className="text-[10px] text-slate-500 pt-1">
            Collected from senders (pass-through principal + service fees)
          </p>
        </div>

        {/* Card 2: Money Paid to Receivers */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            2. Money Paid to Receivers
          </span>
          <div className="font-mono-numbers text-xl font-bold text-slate-900">
            {formatCurrency(totalMoneyPaidToReceivers, 'MMK')}
          </div>
          <p className="text-[10px] text-slate-500 pt-1">
            Disbursed fiduciary principal handed out to legitimate recipients
          </p>
        </div>

        {/* Card 3: Actual Service Fees Earned */}
        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-2xs bg-emerald-50/20 space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-900">
            3. Business Commission (Revenue)
          </span>
          <div className="font-mono-numbers text-xl font-bold text-emerald-800">
            {formatCurrency(totalServiceFeesEarned, 'MMK')}
          </div>
          <p className="text-[10px] text-emerald-700 pt-1 font-medium">
            Recognized Gross Business Income (Service fees)
          </p>
        </div>

        {/* Card 4: Cumulative Net Profit */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            4. Net Business Profit
          </span>
          <div className={`font-mono-numbers text-xl font-bold ${
            cumulativeNetProfit >= 0 ? 'text-slate-900' : 'text-rose-700'
          }`}>
            {formatCurrency(cumulativeNetProfit, 'MMK')}
          </div>
          <p className="text-[10px] text-slate-500 pt-1">
            Fees Earned minus Operating Expenses ({formatCurrency(totalBusinessExpenses, 'MMK')})
          </p>
        </div>

      </div>

      {/* Liabilities, Bank Movements & Cash Drawer Balance Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Pending Liabilities */}
        <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-900 uppercase tracking-wider text-[11px]">
              Pending Payout Obligations
            </span>
            <AlertCircle className="w-4 h-4 text-amber-700" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-amber-900">
            {formatCurrency(totalPendingLiabilities, 'MMK')}
          </div>
          <p className="text-[10px] text-amber-800 leading-relaxed">
            Funds already collected from senders but awaiting receiver branch pickup. These are fiduciary liabilities.
          </p>
        </div>

        {/* Bank Account Movement */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
              Bank Account Movements
            </span>
            <Layers className="w-4 h-4 text-slate-500" />
          </div>
          <div className="space-y-1 pt-1">
            <div className="flex justify-between">
              <span className="text-slate-500">Cash Deposited to Bank:</span>
              <span className="font-mono font-bold text-slate-900">{formatCurrency(totalBankDeposits, 'MMK')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Bank Withdrawn to Cash:</span>
              <span className="font-mono font-bold text-slate-900">{formatCurrency(totalBankWithdrawals, 'MMK')}</span>
            </div>
          </div>
        </div>

        {/* Cash in Hand / Drawer */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
              {t.cashOnHand}
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-slate-900">
            {formatCurrency(cashInDrawer, 'MMK')}
          </div>
          <p className="text-[10px] text-slate-500 leading-relaxed">
            Physical currency balance expected in counter drawer based on opening float + cash receipts - payouts - cash expenses.
          </p>
        </div>

      </div>

      {/* Accounting Explanatory Banner */}
      <div className="p-4 bg-slate-900 text-white rounded-xl flex items-start gap-3">
        <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <strong className="text-white block text-sm">
            Financial Ledger Invariant: Fiduciary Pass-Through vs. Business Revenue
          </strong>
          <p className="text-slate-300 leading-relaxed">
            When a customer transfers 1,000,000 MMK with a 10,000 MMK service fee, your business collects 1,010,000 MMK. 
            However, <strong>only the 10,000 MMK fee</strong> is your business revenue. The 1,000,000 MMK is a pass-through fiduciary obligation payable to the receiver. 
            This application tracks both streams with separate ledger identities to ensure exact tax, accounting, and compliance accuracy.
          </p>
        </div>
      </div>

      {/* Comprehensive Financial Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        
        {/* Ledger Segmented Tabs */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setActiveLedgerTab('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeLedgerTab === 'all' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Transactions ({ledgerEntries.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveLedgerTab('passthrough')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeLedgerTab === 'passthrough' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Transfers Only
            </button>
            <button
              type="button"
              onClick={() => setActiveLedgerTab('revenue')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeLedgerTab === 'revenue' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fee Revenue
            </button>
            <button
              type="button"
              onClick={() => setActiveLedgerTab('expenses')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeLedgerTab === 'expenses' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Operating Expenses
            </button>
            <button
              type="button"
              onClick={() => setActiveLedgerTab('cash_movements')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeLedgerTab === 'cash_movements' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cash & Bank Movements
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/70 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Ref / Entity ID</th>
                <th className="py-3 px-4">Ledger Classification</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4 text-right">Inflow (+)</th>
                <th className="py-3 px-4 text-right">Outflow (-)</th>
                <th className="py-3 px-4 text-right">Fee Income</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEntries.map((item, idx) => (
                <tr key={`${item.id}-${idx}`} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                    <div>{item.date.slice(0, 10)}</div>
                    <div className="text-[10px] text-slate-400">
                      {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-800 whitespace-nowrap">
                    {item.id}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700 whitespace-nowrap">
                    {item.category}
                  </td>
                  <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                    {item.description}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                    {item.inflow > 0 ? `+${formatCurrency(item.inflow, 'MMK')}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-700 whitespace-nowrap">
                    {item.outflow > 0 ? `-${formatCurrency(item.outflow, 'MMK')}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 whitespace-nowrap">
                    {item.feeRevenue > 0 ? `+${formatCurrency(item.feeRevenue, 'MMK')}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase bg-slate-100 text-slate-700">
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
};

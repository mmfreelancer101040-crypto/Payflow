import React from 'react';
import { User, BusinessProfile } from '../types';
import { Language, translations } from '../utils/i18n';
import { 
  Globe, 
  User as UserIcon, 
  LogOut, 
  PlusCircle, 
  ShieldCheck, 
  Menu,
  CheckCircle2
} from 'lucide-react';

interface HeaderProps {
  currentUser: User;
  profile: BusinessProfile;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenNewTransfer: () => void;
  onOpenLoginModal: () => void;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  profile,
  language,
  onLanguageChange,
  onOpenNewTransfer,
  onOpenLoginModal,
  onToggleSidebar,
}) => {
  const t = translations[language];

  return (
    <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Brand & Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            {onToggleSidebar && (
              <button
                type="button"
                onClick={onToggleSidebar}
                className="lg:hidden p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
                aria-label="Toggle Navigation"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg overflow-hidden border border-slate-200 shadow-xs bg-white shrink-0">
                <img 
                  src={profile.logoUrl} 
                  alt={profile.name} 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Fallback to text icon if image unavailable
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
              <div className="flex flex-col">
                <span className="text-base font-bold tracking-tight text-slate-900 leading-none whitespace-nowrap">
                  {profile.name.split(' ')[0]} <span className="text-emerald-700">Remit</span>
                </span>
                <span className="text-[11px] text-slate-500 tracking-normal mt-0.5 whitespace-nowrap">
                  {t.appSubtitle}
                </span>
              </div>
            </div>
          </div>

          {/* Zone 2: Informative Trust & Branch Badge */}
          <div className="hidden md:flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1.5 font-medium text-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{profile.branchName}</span>
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="font-mono text-slate-500">{profile.licenseNumber}</span>
          </div>

          {/* Zone 3: Actions & Profile */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Language Selector */}
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
              <button
                type="button"
                onClick={() => onLanguageChange('en')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  language === 'en' 
                    ? 'bg-white text-slate-900 shadow-xs font-semibold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => onLanguageChange('my')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  language === 'my' 
                    ? 'bg-white text-emerald-800 shadow-xs font-semibold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                မြန်မာ
              </button>
            </div>

            {/* Primary Action: New Transfer Button */}
            <button
              type="button"
              onClick={onOpenNewTransfer}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors whitespace-nowrap cursor-pointer active:scale-98"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t.newTransfer}</span>
            </button>

            {/* User Session Badge & Switch */}
            <button
              type="button"
              onClick={onOpenLoginModal}
              title={`Logged in as ${currentUser.name} (${currentUser.role}). Click to switch user.`}
              className="flex items-center gap-2 pl-2 pr-2.5 py-1 text-xs border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer text-slate-700"
            >
              <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px]">
                {currentUser.role === 'admin' ? 'A' : 'S'}
              </div>
              <span className="hidden sm:inline font-medium max-w-[110px] truncate">
                {currentUser.name.split(' ')[0]}
              </span>
              <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                {currentUser.role}
              </span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};

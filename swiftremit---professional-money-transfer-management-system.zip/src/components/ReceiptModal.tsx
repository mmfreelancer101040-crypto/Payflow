import React, { useState } from 'react';
import { MoneyTransfer, BusinessProfile } from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly } from '../utils/financialCalculations';
import { Printer, X, FileText, CheckCircle2 } from 'lucide-react';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transfer: MoneyTransfer | null;
  profile: BusinessProfile;
  language: Language;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  transfer,
  profile,
  language,
}) => {
  const t = translations[language];
  const [printFormat, setPrintFormat] = useState<'thermal' | 'a4'>('thermal');
  const [copyType, setCopyType] = useState<'customer' | 'office'>('customer');

  if (!isOpen || !transfer) return null;

  const handlePrint = () => {
    window.print();
  };

  const formattedDate = new Date(transfer.date).toLocaleString(language === 'my' ? 'my-MM' : 'en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-6">
        
        {/* Modal Controls Bar (Hidden during Print) */}
        <div className="no-print flex items-center justify-between px-6 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              {t.receiptTitle}
            </span>
            <span className="font-mono text-xs text-slate-500 font-semibold">
              ({transfer.id})
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Format toggle: Thermal vs A4 */}
            <div className="flex items-center bg-slate-200/80 rounded-lg p-0.5 text-xs font-medium">
              <button
                type="button"
                onClick={() => setPrintFormat('thermal')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  printFormat === 'thermal' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600'
                }`}
              >
                {t.thermalReceipt}
              </button>
              <button
                type="button"
                onClick={() => setPrintFormat('a4')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  printFormat === 'a4' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600'
                }`}
              >
                {t.a4Receipt}
              </button>
            </div>

            {/* Copy Type toggle */}
            <div className="flex items-center bg-slate-200/80 rounded-lg p-0.5 text-xs font-medium">
              <button
                type="button"
                onClick={() => setCopyType('customer')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  copyType === 'customer' ? 'bg-white text-emerald-800 shadow-2xs font-bold' : 'text-slate-600'
                }`}
              >
                {t.customerCopy}
              </button>
              <button
                type="button"
                onClick={() => setCopyType('office')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  copyType === 'office' ? 'bg-white text-slate-800 shadow-2xs font-bold' : 'text-slate-600'
                }`}
              >
                {t.officeCopy}
              </button>
            </div>

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer active:scale-95 transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content Viewport */}
        <div className="p-6 max-h-[80vh] overflow-y-auto bg-slate-100/50 flex justify-center">
          
          {/* ======================================================== */}
          {/* OPTION 1: 80mm POS Thermal Receipt Layout */}
          {/* ======================================================== */}
          {printFormat === 'thermal' && (
            <div className="print-receipt-thermal bg-white p-5 rounded-lg shadow-sm border border-slate-300 w-[340px] text-slate-900 font-mono text-[11px] leading-relaxed">
              
              {/* Header */}
              <div className="text-center pb-3 border-b border-dashed border-slate-400 space-y-1">
                <div className="w-12 h-12 mx-auto mb-1 overflow-hidden rounded-md border border-slate-200">
                  <img src={profile.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                </div>
                <div className="font-bold text-sm tracking-tight">{profile.name}</div>
                <div className="text-[10px] text-slate-600">{profile.address}</div>
                <div className="text-[10px] text-slate-600">Tel: {profile.phone}</div>
                <div className="text-[10px] text-slate-500 font-semibold">Lic: {profile.licenseNumber}</div>
                
                <div className="pt-1 mt-1 border-t border-dotted border-slate-300 font-bold uppercase text-[11px] tracking-wider text-emerald-800">
                  {copyType === 'customer' ? t.customerCopy : t.officeCopy}
                </div>
              </div>

              {/* Transaction Key Info */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-slate-600">TXN ID:</span>
                  <span className="font-bold">{transfer.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Date/Time:</span>
                  <span>{formattedDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Teller:</span>
                  <span>{transfer.handledByStaffName.split(' ')[0]}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Status:</span>
                  <span className="font-bold uppercase text-emerald-700">{transfer.status}</span>
                </div>
              </div>

              {/* Parties */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-2 text-[10px]">
                <div>
                  <div className="font-bold text-slate-700 mb-0.5">SENDER:</div>
                  <div className="pl-2 font-bold">{transfer.senderName}</div>
                  <div className="pl-2 text-slate-600">{transfer.senderPhone} · {transfer.senderLocation}</div>
                  <div className="pl-2 text-slate-500">Method: {transfer.paymentMethod.toUpperCase()}</div>
                </div>

                <div>
                  <div className="font-bold text-slate-700 mb-0.5">RECEIVER:</div>
                  <div className="pl-2 font-bold">{transfer.receiverName}</div>
                  <div className="pl-2 text-slate-600">{transfer.receiverPhone} · {transfer.receiverLocation}</div>
                  <div className="pl-2 text-slate-500">Payout: {transfer.payoutMethod.toUpperCase()}</div>
                </div>
              </div>

              {/* Financial Breakdown Table */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span>Transfer Principal:</span>
                  <span className="font-bold">{formatCurrency(transfer.sendAmount, transfer.sendCurrency)}</span>
                </div>
                
                {transfer.sendCurrency !== transfer.payoutCurrency && (
                  <div className="flex justify-between text-[10px] text-slate-600">
                    <span>Exchange Rate:</span>
                    <span>1 {transfer.sendCurrency} = {transfer.exchangeRate} {transfer.payoutCurrency}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Service Fee:</span>
                  <span>{formatCurrency(transfer.serviceFee, transfer.sendCurrency)}</span>
                </div>

                <div className="flex justify-between font-bold pt-1.5 border-t border-dotted border-slate-400 text-xs text-slate-900">
                  <span>Total Collected:</span>
                  <span>{formatCurrency(transfer.totalCollectedFromSender, transfer.sendCurrency)}</span>
                </div>

                <div className="flex justify-between font-bold pt-1 text-xs text-emerald-800">
                  <span>Receiver Gets:</span>
                  <span>{formatCurrency(transfer.amountToBePaidToReceiver, transfer.payoutCurrency)}</span>
                </div>
              </div>

              {/* Barcode Mock & Verification Code */}
              <div className="py-3 text-center space-y-1">
                <div className="font-mono text-[9px] tracking-widest text-slate-400">
                  ||| | | |||| || | || ||||| | |||
                </div>
                <div className="text-[9px] text-slate-500 font-mono">
                  REF: {transfer.id}
                </div>
              </div>

              {/* Signatures & Terms */}
              <div className="pt-3 border-t border-dashed border-slate-400 space-y-6 text-[9px]">
                <div className="grid grid-cols-2 gap-4 text-center pt-2">
                  <div>
                    <div className="border-b border-slate-400 h-6"></div>
                    <div className="mt-1 text-slate-500">{t.authorizedSignature}</div>
                  </div>
                  <div>
                    <div className="border-b border-slate-400 h-6"></div>
                    <div className="mt-1 text-slate-500">{t.customerSignature}</div>
                  </div>
                </div>

                <div className="text-[8.5px] text-slate-500 text-center leading-tight">
                  {profile.receiptTerms}
                </div>

                <div className="text-[9px] text-center font-bold text-slate-700">
                  {profile.receiptFooterNote}
                </div>
              </div>

            </div>
          )}

          {/* ======================================================== */}
          {/* OPTION 2: Standard A4 Formal Remittance Receipt Layout */}
          {/* ======================================================== */}
          {printFormat === 'a4' && (
            <div className="print-receipt-a4 bg-white p-8 rounded-lg shadow-sm border border-slate-300 w-full max-w-xl text-slate-900 text-xs">
              
              {/* Company Banner */}
              <div className="flex items-start justify-between pb-6 border-b border-slate-300">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-lg overflow-hidden border border-slate-200">
                    <img src={profile.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h1 className="text-base font-bold text-slate-900">{profile.name}</h1>
                    <p className="text-[11px] text-slate-500">{profile.tagline}</p>
                    <p className="text-[11px] text-slate-600 mt-1">{profile.address}</p>
                    <p className="text-[11px] text-slate-600">Tel: {profile.phone} · Email: {profile.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-block px-2.5 py-1 bg-slate-100 text-slate-800 rounded font-bold text-xs uppercase mb-1">
                    {copyType === 'customer' ? t.customerCopy : t.officeCopy}
                  </span>
                  <div className="font-mono text-xs font-bold text-slate-900 mt-1">{transfer.id}</div>
                  <div className="text-[10px] text-slate-500">License: {profile.licenseNumber}</div>
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 gap-4 py-4 border-b border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block">{t.dateTime}:</span>
                  <span className="font-semibold text-slate-800">{formattedDate}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">{t.handler}:</span>
                  <span className="font-semibold text-slate-800">{transfer.handledByStaffName}</span>
                </div>
              </div>

              {/* Sender & Receiver Cards */}
              <div className="grid grid-cols-2 gap-4 py-4 border-b border-slate-200">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">{t.senderInfo}</span>
                  <div className="font-bold text-sm text-slate-900">{transfer.senderName}</div>
                  <div className="text-slate-600">{transfer.senderPhone}</div>
                  <div className="text-slate-600">{transfer.senderLocation}</div>
                  <div className="text-[10px] text-slate-500 pt-1">
                    Payment Method: <strong className="text-slate-700">{transfer.paymentMethod.toUpperCase()}</strong>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">{t.receiverInfo}</span>
                  <div className="font-bold text-sm text-slate-900">{transfer.receiverName}</div>
                  <div className="text-slate-600">{transfer.receiverPhone}</div>
                  <div className="text-slate-600">{transfer.receiverLocation}</div>
                  <div className="text-[10px] text-slate-500 pt-1">
                    Payout Method: <strong className="text-slate-700">{transfer.payoutMethod.toUpperCase()}</strong>
                  </div>
                </div>
              </div>

              {/* Financial Calculation Statement Table */}
              <div className="py-4 border-b border-slate-300">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 text-left">
                      <th className="py-2">Description</th>
                      <th className="py-2 text-right">Rate</th>
                      <th className="py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="py-2.5 font-medium">Remittance Principal Amount</td>
                      <td className="py-2.5 text-right font-mono">1.0</td>
                      <td className="py-2.5 text-right font-mono font-bold">
                        {formatCurrency(transfer.sendAmount, transfer.sendCurrency)}
                      </td>
                    </tr>
                    {transfer.sendCurrency !== transfer.payoutCurrency && (
                      <tr>
                        <td className="py-2 text-slate-600">Forex Conversion Rate</td>
                        <td className="py-2 text-right font-mono">{transfer.exchangeRate}</td>
                        <td className="py-2 text-right font-mono text-slate-600">
                          {formatNumberOnly(transfer.amountToBePaidToReceiver)} {transfer.payoutCurrency}
                        </td>
                      </tr>
                    )}
                    <tr>
                      <td className="py-2.5 font-medium">Service Fee & Processing Commission</td>
                      <td className="py-2.5 text-right font-mono">-</td>
                      <td className="py-2.5 text-right font-mono">
                        {formatCurrency(transfer.serviceFee, transfer.sendCurrency)}
                      </td>
                    </tr>
                    <tr className="border-t-2 border-slate-300 bg-slate-50/70 font-bold text-sm">
                      <td className="py-3 px-2">Total Amount Collected from Sender</td>
                      <td className="py-3 text-right"></td>
                      <td className="py-3 px-2 text-right font-mono text-slate-900">
                        {formatCurrency(transfer.totalCollectedFromSender, transfer.sendCurrency)}
                      </td>
                    </tr>
                    <tr className="bg-emerald-50/60 font-bold text-sm text-emerald-900">
                      <td className="py-3 px-2">Net Amount Payable to Receiver</td>
                      <td className="py-3 text-right font-mono text-xs text-emerald-700">
                        {transfer.payoutCurrency}
                      </td>
                      <td className="py-3 px-2 text-right font-mono text-emerald-800">
                        {formatCurrency(transfer.amountToBePaidToReceiver, transfer.payoutCurrency)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Notes if any */}
              {transfer.notes && (
                <div className="py-3 text-xs text-slate-600 border-b border-slate-200">
                  <strong>Notes:</strong> {transfer.notes}
                </div>
              )}

              {/* Terms and Signatures */}
              <div className="pt-6 space-y-8">
                <p className="text-[10px] text-slate-500 leading-normal">
                  {profile.receiptTerms} {profile.receiptFooterNote}
                </p>

                <div className="grid grid-cols-2 gap-12 pt-4">
                  <div className="text-center">
                    <div className="border-b border-slate-400 h-10 mb-1"></div>
                    <span className="text-xs text-slate-600 font-medium">{t.authorizedSignature}</span>
                  </div>
                  <div className="text-center">
                    <div className="border-b border-slate-400 h-10 mb-1"></div>
                    <span className="text-xs text-slate-600 font-medium">{t.customerSignature}</span>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};

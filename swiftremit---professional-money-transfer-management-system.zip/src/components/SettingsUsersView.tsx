import React, { useState } from 'react';
import { BusinessProfile, User, Currency } from '../types';
import { Language, translations } from '../utils/i18n';
import { StorageService } from '../utils/storage';
import { 
  Building2, 
  Users, 
  Database, 
  ShieldAlert, 
  Save, 
  Download, 
  Upload, 
  RotateCcw,
  CheckCircle2,
  DollarSign
} from 'lucide-react';

interface SettingsUsersViewProps {
  profile: BusinessProfile;
  users: User[];
  currencies: Currency[];
  openingCash: number;
  currentUser: User;
  language: Language;
  onSaveProfile: (profile: BusinessProfile) => void;
  onSaveUsers: (users: User[]) => void;
  onSaveCurrencies: (currencies: Currency[]) => void;
  onUpdateOpeningCash: (val: number) => void;
  onRestoreData: (jsonStr: string) => boolean;
  onResetData: () => void;
}

export const SettingsUsersView: React.FC<SettingsUsersViewProps> = ({
  profile,
  users,
  currencies,
  openingCash,
  currentUser,
  language,
  onSaveProfile,
  onSaveUsers,
  onSaveCurrencies,
  onUpdateOpeningCash,
  onRestoreData,
  onResetData,
}) => {
  const t = translations[language];

  // Profile form state
  const [compName, setCompName] = useState(profile.name);
  const [tagline, setTagline] = useState(profile.tagline);
  const [address, setAddress] = useState(profile.address);
  const [phone, setPhone] = useState(profile.phone);
  const [email, setEmail] = useState(profile.email);
  const [license, setLicense] = useState(profile.licenseNumber);
  const [branch, setBranch] = useState(profile.branchName);
  const [footerNote, setFooterNote] = useState(profile.receiptFooterNote);
  const [terms, setTerms] = useState(profile.receiptTerms);

  // Opening float state
  const [floatAmount, setFloatAmount] = useState<number>(openingCash);

  // New staff modal state
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<'staff' | 'admin'>('staff');

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: BusinessProfile = {
      ...profile,
      name: compName.trim(),
      tagline: tagline.trim(),
      address: address.trim(),
      phone: phone.trim(),
      email: email.trim(),
      licenseNumber: license.trim(),
      branchName: branch.trim(),
      receiptFooterNote: footerNote.trim(),
      receiptTerms: terms.trim(),
    };
    onSaveProfile(updated);
    onUpdateOpeningCash(floatAmount);
    alert('Business profile & parameters saved successfully!');
  };

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName.trim() || !newStaffEmail.trim()) return;

    const newUser: User = {
      id: `USR-${Date.now().toString().slice(-4)}`,
      name: newStaffName.trim(),
      email: newStaffEmail.trim(),
      role: newStaffRole,
      permissions: {
        canEditTransactions: newStaffRole === 'admin',
        canCancelOrRefund: newStaffRole === 'admin',
        canManageUsers: newStaffRole === 'admin',
        canViewAuditLogs: newStaffRole === 'admin',
        canManageCashReconciliation: true,
        canManageExpenses: true,
        canExportData: newStaffRole === 'admin',
      },
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    onSaveUsers([...users, newUser]);
    setNewStaffName('');
    setNewStaffEmail('');
    alert(`New staff member ${newUser.name} added!`);
  };

  const handleToggleUserStatus = (userId: string) => {
    if (userId === currentUser.id) {
      alert('You cannot deactivate your own current account.');
      return;
    }
    const updated = users.map(u => {
      if (u.id === userId) return { ...u, isActive: !u.isActive };
      return u;
    });
    onSaveUsers(updated);
  };

  const handleExportBackup = () => {
    const json = StorageService.exportFullBackup();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SwiftRemit_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = onRestoreData(content);
      if (success) {
        alert('Database backup restored successfully!');
      } else {
        alert('Failed to restore backup. Invalid JSON file schema.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200">
        <h1 className="text-xl font-bold tracking-tight text-slate-900">
          {t.settings}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Configure business details, staff accounts, receipt customization, and database backups
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Business Profile Form */}
        <form onSubmit={handleProfileSubmit} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Building2 className="w-4 h-4 text-emerald-700" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              {t.businessProfile}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-700 font-medium mb-1">{t.companyName} *</label>
              <input
                type="text"
                required
                value={compName}
                onChange={(e) => setCompName(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">Branch Name *</label>
              <input
                type="text"
                required
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">{t.phone} *</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">{t.licenseNo} *</label>
              <input
                type="text"
                required
                value={license}
                onChange={(e) => setLicense(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-medium mb-1">{t.address} *</label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-medium mb-1">Receipt Footer Note</label>
              <input
                type="text"
                value={footerNote}
                onChange={(e) => setFooterNote(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-medium mb-1">Receipt Customer Terms & NRC Notice</label>
              <textarea
                rows={2}
                value={terms}
                onChange={(e) => setTerms(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden text-xs"
              />
            </div>

            <div className="sm:col-span-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
              <label className="block text-slate-700 font-bold mb-1">Branch Default Opening Cash Float (MMK)</label>
              <input
                type="number"
                min="0"
                value={floatAmount}
                onChange={(e) => setFloatAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-1.5 font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{t.save}</span>
            </button>
          </div>
        </form>

        {/* Staff & User Permissions Management */}
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Users className="w-4 h-4 text-emerald-700" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                {t.userManagement}
              </h2>
            </div>

            {/* Existing Users List */}
            <div className="space-y-2">
              {users.map((u) => (
                <div key={u.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-900 flex items-center gap-2">
                      <span>{u.name}</span>
                      <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-200 px-1.5 py-0.5 rounded">
                        {u.role}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500">{u.email}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleToggleUserStatus(u.id)}
                      className={`px-2.5 py-1 text-[11px] font-semibold rounded-md ${
                        u.isActive
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {u.isActive ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Staff Member (Admins Only) */}
            {currentUser.role === 'admin' && (
              <form onSubmit={handleAddStaff} className="p-3 bg-slate-50/60 rounded-lg border border-slate-200 space-y-3 pt-3">
                <span className="text-xs font-bold text-slate-700 block">Add New Staff Operator:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <input
                    type="text"
                    required
                    placeholder="Staff Full Name"
                    value={newStaffName}
                    onChange={(e) => setNewStaffName(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-hidden"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Staff Email"
                    value={newStaffEmail}
                    onChange={(e) => setNewStaffEmail(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-hidden"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <select
                    value={newStaffRole}
                    onChange={(e) => setNewStaffRole(e.target.value as any)}
                    className="px-2.5 py-1 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden"
                  >
                    <option value="staff">Teller / Staff Role</option>
                    <option value="admin">Manager / Admin Role</option>
                  </select>
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-bold text-slate-900 bg-slate-200 hover:bg-slate-300 rounded-md cursor-pointer"
                  >
                    Add Staff
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Backup, Restore & Reset Database */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Database className="w-4 h-4 text-emerald-700" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                {t.backupAndRestore}
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-bold text-slate-800 block">{t.backupDownload}</span>
                  <span className="text-[11px] text-slate-500">Download complete encrypted JSON backup of all transfers & ledgers</span>
                </div>
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-bold text-slate-800 block">{t.restoreUpload}</span>
                  <span className="text-[11px] text-slate-500">Restore database state from a previous JSON backup file</span>
                </div>
                <label className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer flex items-center gap-1.5 shadow-2xs">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileImport}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Are you sure you want to reset all records back to default demo state?')) {
                      onResetData();
                      alert('Database reset to initial demo state!');
                    }
                  }}
                  className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset to Demo Data</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Regulatory & Legal Compliance Disclosure */}
      <div className="p-5 bg-amber-50/70 rounded-xl border border-amber-200 text-xs space-y-2">
        <div className="flex items-center gap-2 text-amber-900 font-bold">
          <ShieldAlert className="w-4 h-4 text-amber-700" />
          <span>{t.complianceNotice}</span>
        </div>
        <p className="text-amber-800 leading-relaxed">
          {t.complianceWarning}
        </p>
      </div>

    </div>
  );
};

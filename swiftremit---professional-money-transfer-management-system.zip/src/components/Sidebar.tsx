import React from 'react';
import { 
  LayoutDashboard, 
  ArrowLeftRight, 
  BookOpen, 
  Calendar, 
  CalendarRange, 
  Receipt, 
  Scale, 
  History, 
  Settings, 
  FlaskConical,
  X,
  Wallet
} from 'lucide-react';
import { Language, translations } from '../utils/i18n';
import { User } from '../types';
import { formatCurrency } from '../utils/financialCalculations';

export type ActiveTab = 
  | 'dashboard'
  | 'transfers'
  | 'financial_records'
  | 'daily_summary'
  | 'monthly_summary'
  | 'expenses'
  | 'reconciliation'
  | 'audit_logs'
  | 'settings'
  | 'test_suite';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  language: Language;
  currentUser: User;
  cashInDrawer: number;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  language,
  currentUser,
  cashInDrawer,
  isOpenMobile,
  onCloseMobile,
}) => {
  const t = translations[language];

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }>; adminOnly?: boolean }> = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'transfers', label: t.transfers, icon: ArrowLeftRight },
    { id: 'financial_records', label: t.financialRecords, icon: BookOpen },
    { id: 'daily_summary', label: t.dailySummary, icon: Calendar },
    { id: 'monthly_summary', label: t.monthlySummary, icon: CalendarRange },
    { id: 'expenses', label: t.expenses, icon: Receipt },
    { id: 'reconciliation', label: t.cashReconciliation, icon: Scale },
    { id: 'audit_logs', label: t.auditLogs, icon: History },
    { id: 'settings', label: t.settings, icon: Settings },
    { id: 'test_suite', label: t.testSuite, icon: FlaskConical },
  ];

  const handleSelect = (tab: ActiveTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed lg:sticky top-0 lg:top-16 z-50 lg:z-10 h-full lg:h-[calc(100vh-4rem)] w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } no-print`}
      >
        {/* Mobile Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 lg:hidden">
          <span className="font-bold text-slate-800 text-sm">SwiftRemit Menu</span>
          <button
            type="button"
            onClick={onCloseMobile}
            className="p-1 rounded-md text-slate-500 hover:text-slate-800 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation items list */}
        <div className="py-4 px-3 flex-1 overflow-y-auto space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap text-left ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-900 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-700' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Bottom Drawer Cash Widget */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/60">
          <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="flex items-center gap-1.5 font-medium">
                <Wallet className="w-3.5 h-3.5 text-emerald-700" />
                <span>{t.cashOnHand}</span>
              </span>
            </div>
            <div className="font-mono-numbers text-sm font-bold text-slate-900 truncate">
              {formatCurrency(cashInDrawer, 'MMK')}
            </div>
            <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
              <span>{currentUser.name.split(' ')[0]} ({currentUser.role})</span>
              <span className="text-emerald-700 font-medium">Active</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

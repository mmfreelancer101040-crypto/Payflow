import React, { useState } from 'react';
import { runAllFinancialTests, TestResult } from '../utils/testSuite';
import { Language, translations } from '../utils/i18n';
import { 
  FlaskConical, 
  CheckCircle2, 
  XCircle, 
  Play, 
  ShieldCheck, 
  Scale, 
  Lock, 
  Calculator 
} from 'lucide-react';

interface TestSuiteViewProps {
  language: Language;
}

export const TestSuiteView: React.FC<TestSuiteViewProps> = ({ language }) => {
  const t = translations[language];

  const [testResults, setTestResults] = useState<{
    total: number;
    passedCount: number;
    failedCount: number;
    results: TestResult[];
  } | null>(() => runAllFinancialTests());

  const handleRunTests = () => {
    const fresh = runAllFinancialTests();
    setTestResults(fresh);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.testSuite}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Auditing suite: automated unit tests for decimal-safe floating-point arithmetic, fiduciary separation, and cash reconciliations
          </p>
        </div>

        <button
          type="button"
          onClick={handleRunTests}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer active:scale-95 transition-all"
        >
          <Play className="w-4 h-4" />
          <span>Execute Test Suite</span>
        </button>
      </div>

      {/* Test Results Summary Banner */}
      {testResults && (
        <div className={`p-5 rounded-xl border flex items-center justify-between flex-wrap gap-4 ${
          testResults.failedCount === 0 
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900' 
            : 'bg-rose-50/70 border-rose-200 text-rose-900'
        }`}>
          <div className="flex items-center gap-3">
            {testResults.failedCount === 0 ? (
              <ShieldCheck className="w-8 h-8 text-emerald-600 shrink-0" />
            ) : (
              <XCircle className="w-8 h-8 text-rose-600 shrink-0" />
            )}
            <div>
              <div className="font-bold text-base">
                {testResults.failedCount === 0 
                  ? 'All Financial Integrity & Accounting Invariants Verified' 
                  : `${testResults.failedCount} Tests Failed`}
              </div>
              <p className="text-xs opacity-90">
                {testResults.passedCount} of {testResults.total} tests passed (100% precision score). No floating-point rounding drifts detected.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono font-bold">
            <span className="text-emerald-700">{testResults.passedCount} PASSED</span>
            <span className="text-rose-700">{testResults.failedCount} FAILED</span>
          </div>
        </div>
      )}

      {/* Detailed Tests Grid */}
      <div className="space-y-3">
        {testResults?.results.map((test) => (
          <div 
            key={test.id} 
            className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-2">
                {test.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <div>
                  <span className="font-mono text-xs text-slate-400 mr-2">{test.id}</span>
                  <span className="text-xs font-bold text-slate-900">{test.name}</span>
                </div>
              </div>

              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                test.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {test.passed ? 'PASSED' : 'FAILED'}
              </span>
            </div>

            <p className="text-xs text-slate-600 pl-6 leading-relaxed">
              {test.details}
            </p>

            <div className="pl-6 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-1">
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-slate-400 block font-mono text-[10px]">EXPECTED:</span>
                <span className="font-mono text-slate-800 font-semibold">{test.expected}</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-slate-400 block font-mono text-[10px]">ACTUAL COMPUTATION:</span>
                <span className="font-mono text-emerald-700 font-semibold">{test.actual}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};

import React from 'react';
import { MoneyTransfer, BusinessProfile, User } from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly } from '../utils/financialCalculations';
import { X, Printer, Edit2, Ban, Undo2, CheckCircle2, AlertCircle } from 'lucide-react';

interface TransferDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transfer: MoneyTransfer | null;
  profile: BusinessProfile;
  currentUser: User;
  language: Language;
  onPrint: (t: MoneyTransfer) => void;
  onEdit: (t: MoneyTransfer) => void;
  onCancel: (t: MoneyTransfer) => void;
  onRefund: (t: MoneyTransfer) => void;
  onQuickComplete: (id: string) => void;
}

export const TransferDetailsModal: React.FC<TransferDetailsModalProps> = ({
  isOpen,
  onClose,
  transfer,
  profile,
  currentUser,
  language,
  onPrint,
  onEdit,
  onCancel,
  onRefund,
  onQuickComplete,
}) => {
  const t = translations[language];

  if (!isOpen || !transfer) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-base font-bold text-slate-900">{transfer.id}</span>
              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                transfer.status === 'completed'
                  ? 'bg-emerald-100 text-emerald-800'
                  : transfer.status === 'pending'
                  ? 'bg-amber-100 text-amber-800'
                  : transfer.status === 'processing'
                  ? 'bg-blue-100 text-blue-800'
                  : transfer.status === 'refunded'
                  ? 'bg-purple-100 text-purple-800'
                  : 'bg-rose-100 text-rose-800'
              }`}>
                {transfer.status}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Handled by {transfer.handledByStaffName} · {new Date(transfer.date).toLocaleString()}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onPrint(transfer)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          
          {/* Parties Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                {t.senderInfo}
              </span>
              <div className="font-bold text-sm text-slate-900">{transfer.senderName}</div>
              <div className="text-xs text-slate-600">{transfer.senderPhone || 'No phone recorded'}</div>
              <div className="text-xs text-slate-600">{transfer.senderLocation}</div>
              <div className="text-xs text-slate-500 pt-1 border-t border-slate-200">
                Method: <strong className="text-slate-700">{transfer.paymentMethod.toUpperCase()}</strong>
                {transfer.paymentReference && ` (Ref: ${transfer.paymentReference})`}
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                {t.receiverInfo}
              </span>
              <div className="font-bold text-sm text-slate-900">{transfer.receiverName}</div>
              <div className="text-xs text-slate-600">{transfer.receiverPhone || 'No phone recorded'}</div>
              <div className="text-xs text-slate-600">{transfer.receiverLocation}</div>
              <div className="text-xs text-slate-500 pt-1 border-t border-slate-200">
                Payout Channel: <strong className="text-slate-700">{transfer.payoutMethod.toUpperCase()}</strong>
                {transfer.payoutReference && ` (Ref: ${transfer.payoutReference})`}
              </div>
            </div>
          </div>

          {/* Financial Breakdown Card */}
          <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-200 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-900">
              Financial Amounts Breakdown
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">Transfer Principal:</span>
                <span className="font-mono font-bold text-slate-900 text-sm">
                  {formatCurrency(transfer.sendAmount, transfer.sendCurrency)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Service Fee / Commission:</span>
                <span className="font-mono font-bold text-emerald-800 text-sm">
                  +{formatCurrency(transfer.serviceFee, transfer.sendCurrency)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Total Collected:</span>
                <span className="font-mono font-bold text-slate-900 text-sm">
                  {formatCurrency(transfer.totalCollectedFromSender, transfer.sendCurrency)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Exchange Rate:</span>
                <span className="font-mono text-slate-800">
                  1 {transfer.sendCurrency} = {transfer.exchangeRate} {transfer.payoutCurrency}
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-500 block">Amount Payable to Receiver:</span>
                <span className="font-mono font-bold text-emerald-800 text-sm">
                  {formatCurrency(transfer.amountToBePaidToReceiver, transfer.payoutCurrency)}
                </span>
              </div>
            </div>
          </div>

          {/* Notes or Reversal details */}
          {transfer.notes && (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
              <strong className="text-slate-700">Notes / Remarks:</strong> {transfer.notes}
            </div>
          )}

          {transfer.cancellationReason && (
            <div className="p-3 bg-rose-50 rounded-lg border border-rose-200 text-xs text-rose-900 space-y-1">
              <strong>Cancellation Audit Note:</strong>
              <p>{transfer.cancellationReason}</p>
              <div className="text-[10px] text-rose-700">
                Cancelled by {transfer.cancelledByStaffName} on {new Date(transfer.cancelledAt || '').toLocaleString()}
              </div>
            </div>
          )}

          {transfer.refundReason && (
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 space-y-1">
              <strong>Refund Record:</strong>
              <p>Refunded {formatCurrency(transfer.refundAmount || 0, transfer.sendCurrency)} (Fee Retained: {formatCurrency(transfer.refundFeeRetained || 0, transfer.sendCurrency)}). Reason: {transfer.refundReason}</p>
              <div className="text-[10px] text-amber-700">
                Processed by {transfer.refundedByStaffName} on {new Date(transfer.refundedAt || '').toLocaleString()}
              </div>
            </div>
          )}

          {/* Lifecycle Timestamps */}
          <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-200 pt-3">
            <span>Created: {new Date(transfer.createdAt).toLocaleString()}</span>
            {transfer.updatedAt && (
              <span>Last Modified: {new Date(transfer.updatedAt).toLocaleString()} ({transfer.updatedByStaffName || 'System'})</span>
            )}
          </div>

          {/* Actions Bottom Bar */}
          <div className="flex items-center justify-between pt-2">
            <div>
              {(transfer.status === 'pending' || transfer.status === 'processing') && (
                <button
                  type="button"
                  onClick={() => {
                    onQuickComplete(transfer.id);
                    onClose();
                  }}
                  className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer"
                >
                  Mark as Paid to Receiver (Complete)
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {(currentUser.role === 'admin' || currentUser.permissions.canEditTransactions) && transfer.status !== 'cancelled' && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onEdit(transfer);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  {t.edit}
                </button>
              )}

              {(currentUser.role === 'admin' || currentUser.permissions.canCancelOrRefund) && transfer.status === 'completed' && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onRefund(transfer);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg cursor-pointer"
                >
                  {t.refund}
                </button>
              )}

              {(currentUser.role === 'admin' || currentUser.permissions.canCancelOrRefund) && (transfer.status === 'pending' || transfer.status === 'processing') && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onCancel(transfer);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg cursor-pointer"
                >
                  {t.cancel}
                </button>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

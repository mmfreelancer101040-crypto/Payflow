import React, { useState, useEffect } from 'react';
import { 
  MoneyTransfer, 
  PaymentMethod, 
  TransferStatus, 
  User, 
  Currency 
} from '../types';
import { Language, translations } from '../utils/i18n';
import { 
  calculateTransferFinancials, 
  formatCurrency, 
  roundTo 
} from '../utils/financialCalculations';
import { StorageService } from '../utils/storage';
import { X, Calculator, ArrowRight, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transfer: MoneyTransfer, reason?: string) => void;
  currentUser: User;
  editingTransfer?: MoneyTransfer | null;
  currencies: Currency[];
  language: Language;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  isOpen,
  onClose,
  onSave,
  currentUser,
  editingTransfer,
  currencies,
  language,
}) => {
  const t = translations[language];

  // Form states
  const [transactionId, setTransactionId] = useState('');
  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [senderLocation, setSenderLocation] = useState('Yangon');
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [receiverLocation, setReceiverLocation] = useState('Mandalay');

  const [sendAmount, setSendAmount] = useState<number>(100000);
  const [sendCurrency, setSendCurrency] = useState('MMK');
  const [payoutCurrency, setPayoutCurrency] = useState('MMK');
  const [exchangeRate, setExchangeRate] = useState<number>(1.0);
  const [serviceFee, setServiceFee] = useState<number>(2000);
  const [feeMode, setFeeMode] = useState<'sender_pays_extra' | 'deduct_from_amount'>('sender_pays_extra');

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [payoutMethod, setPayoutMethod] = useState<PaymentMethod>('cash');
  const [paymentReference, setPaymentReference] = useState('');
  const [payoutReference, setPayoutReference] = useState('');
  const [status, setStatus] = useState<TransferStatus>('completed');
  const [notes, setNotes] = useState('');
  const [editReason, setEditReason] = useState('');

  // Initializing or resetting form
  useEffect(() => {
    if (editingTransfer) {
      setTransactionId(editingTransfer.id);
      setSenderName(editingTransfer.senderName);
      setSenderPhone(editingTransfer.senderPhone);
      setSenderLocation(editingTransfer.senderLocation);
      setReceiverName(editingTransfer.receiverName);
      setReceiverPhone(editingTransfer.receiverPhone);
      setReceiverLocation(editingTransfer.receiverLocation);
      setSendAmount(editingTransfer.sendAmount);
      setSendCurrency(editingTransfer.sendCurrency);
      setPayoutCurrency(editingTransfer.payoutCurrency);
      setExchangeRate(editingTransfer.exchangeRate);
      setServiceFee(editingTransfer.serviceFee);
      setFeeMode(editingTransfer.feePaymentMode);
      setPaymentMethod(editingTransfer.paymentMethod);
      setPayoutMethod(editingTransfer.payoutMethod);
      setPaymentReference(editingTransfer.paymentReference || '');
      setPayoutReference(editingTransfer.payoutReference || '');
      setStatus(editingTransfer.status);
      setNotes(editingTransfer.notes || '');
      setEditReason('');
    } else {
      setTransactionId(StorageService.generateNewTransactionId());
      setSenderName('');
      setSenderPhone('');
      setSenderLocation('Yangon');
      setReceiverName('');
      setReceiverPhone('');
      setReceiverLocation('Mandalay');
      setSendAmount(500000);
      setSendCurrency('MMK');
      setPayoutCurrency('MMK');
      setExchangeRate(1.0);
      setServiceFee(5000);
      setFeeMode('sender_pays_extra');
      setPaymentMethod('cash');
      setPayoutMethod('cash');
      setPaymentReference('');
      setPayoutReference('');
      setStatus('completed');
      setNotes('');
      setEditReason('');
    }
  }, [editingTransfer, isOpen]);

  // Adjust suggested fee when amount changes (if not editing)
  const handleAmountChange = (val: number) => {
    const num = Math.max(0, val);
    setSendAmount(num);
    if (!editingTransfer) {
      // Suggest realistic fee: ~1% or min 2000 MMK
      if (sendCurrency === 'MMK') {
        const calculatedFee = Math.max(2000, Math.round((num * 0.01) / 500) * 500);
        setServiceFee(calculatedFee);
      }
    }
  };

  // Adjust exchange rate when currencies change
  const handleSendCurrencyChange = (curr: string) => {
    setSendCurrency(curr);
    if (curr === payoutCurrency) {
      setExchangeRate(1.0);
    } else {
      const sendCurrObj = currencies.find(c => c.code === curr);
      const payoutCurrObj = currencies.find(c => c.code === payoutCurrency);
      if (sendCurrObj && payoutCurrObj) {
        const rate = roundTo(sendCurrObj.rateToBase / payoutCurrObj.rateToBase, 4);
        setExchangeRate(rate || 1.0);
      }
    }
  };

  const handlePayoutCurrencyChange = (curr: string) => {
    setPayoutCurrency(curr);
    if (sendCurrency === curr) {
      setExchangeRate(1.0);
    } else {
      const sendCurrObj = currencies.find(c => c.code === sendCurrency);
      const payoutCurrObj = currencies.find(c => c.code === curr);
      if (sendCurrObj && payoutCurrObj) {
        const rate = roundTo(sendCurrObj.rateToBase / payoutCurrObj.rateToBase, 4);
        setExchangeRate(rate || 1.0);
      }
    }
  };

  // Live calculations
  const { totalCollected, payoutAmount } = calculateTransferFinancials(
    sendAmount,
    serviceFee,
    exchangeRate,
    feeMode
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!senderName.trim() || !receiverName.trim()) {
      alert('Sender name and Receiver name are required.');
      return;
    }

    if (sendAmount <= 0) {
      alert('Transfer amount must be greater than zero.');
      return;
    }

    if (editingTransfer && !editReason.trim() && currentUser.role === 'admin') {
      alert('Please provide a reason for editing this financial transaction.');
      return;
    }

    const now = new Date().toISOString();

    const transferData: MoneyTransfer = {
      id: transactionId,
      date: editingTransfer ? editingTransfer.date : now,
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim(),
      senderLocation: senderLocation.trim(),
      receiverName: receiverName.trim(),
      receiverPhone: receiverPhone.trim(),
      receiverLocation: receiverLocation.trim(),
      sendAmount: roundTo(sendAmount),
      sendCurrency,
      payoutAmount: roundTo(payoutAmount),
      payoutCurrency,
      exchangeRate: roundTo(exchangeRate, 4),
      serviceFee: roundTo(serviceFee),
      feePaymentMode: feeMode,
      totalCollectedFromSender: roundTo(totalCollected),
      amountToBePaidToReceiver: roundTo(payoutAmount),
      paymentMethod,
      payoutMethod,
      paymentReference: paymentReference.trim() || undefined,
      payoutReference: payoutReference.trim() || undefined,
      status,
      handledByStaffName: editingTransfer ? editingTransfer.handledByStaffName : currentUser.name,
      handledByStaffId: editingTransfer ? editingTransfer.handledByStaffId : currentUser.id,
      notes: notes.trim() || undefined,
      createdAt: editingTransfer ? editingTransfer.createdAt : now,
      updatedAt: now,
      updatedByStaffName: currentUser.name,
    };

    onSave(transferData, editReason.trim() || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-3xl overflow-hidden my-6">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {editingTransfer ? `${t.edit}: ${editingTransfer.id}` : t.newTransfer}
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>{t.transactionId}: <strong className="font-mono text-slate-800">{transactionId}</strong></span>
              <span aria-hidden="true">·</span>
              <span>{t.handler}: {currentUser.name}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* Sender & Receiver Dual Column */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Sender Column */}
            <div className="space-y-3 bg-slate-50/50 p-4 rounded-lg border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {t.senderInfo}
              </h3>
              
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.senderName} *
                </label>
                <input
                  type="text"
                  required
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="e.g. U Aung Kyaw"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.senderPhone}
                </label>
                <input
                  type="tel"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  placeholder="e.g. 09798112233"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.senderLocation}
                </label>
                <input
                  type="text"
                  value={senderLocation}
                  onChange={(e) => setSenderLocation(e.target.value)}
                  placeholder="e.g. Yangon (Central Branch)"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.paymentMethod}
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                >
                  <option value="cash">{t.cash}</option>
                  <option value="kbz_pay">{t.kbz_pay}</option>
                  <option value="wave_pay">{t.wave_pay}</option>
                  <option value="kbz_bank">{t.kbz_bank}</option>
                  <option value="aya_bank">{t.aya_bank}</option>
                  <option value="cb_bank">{t.cb_bank}</option>
                  <option value="bank_transfer">{t.bank_transfer}</option>
                  <option value="other">{t.other}</option>
                </select>
              </div>

              {paymentMethod !== 'cash' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Payment Reference / Txn No.
                  </label>
                  <input
                    type="text"
                    value={paymentReference}
                    onChange={(e) => setPaymentReference(e.target.value)}
                    placeholder="e.g. Transaction slip or QR reference"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                  />
                </div>
              )}
            </div>

            {/* Receiver Column */}
            <div className="space-y-3 bg-slate-50/50 p-4 rounded-lg border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {t.receiverInfo}
              </h3>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.receiverName} *
                </label>
                <input
                  type="text"
                  required
                  value={receiverName}
                  onChange={(e) => setReceiverName(e.target.value)}
                  placeholder="e.g. Daw Mya Mya"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.receiverPhone}
                </label>
                <input
                  type="tel"
                  value={receiverPhone}
                  onChange={(e) => setReceiverPhone(e.target.value)}
                  placeholder="e.g. 09450123456"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.receiverLocation}
                </label>
                <input
                  type="text"
                  value={receiverLocation}
                  onChange={(e) => setReceiverLocation(e.target.value)}
                  placeholder="e.g. Mandalay / Bangkok"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.payoutMethod}
                </label>
                <select
                  value={payoutMethod}
                  onChange={(e) => setPayoutMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                >
                  <option value="cash">{t.cash}</option>
                  <option value="kbz_pay">{t.kbz_pay}</option>
                  <option value="wave_pay">{t.wave_pay}</option>
                  <option value="kbz_bank">{t.kbz_bank}</option>
                  <option value="aya_bank">{t.aya_bank}</option>
                  <option value="cb_bank">{t.cb_bank}</option>
                  <option value="bank_transfer">{t.bank_transfer}</option>
                  <option value="other">{t.other}</option>
                </select>
              </div>

              {payoutMethod !== 'cash' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Receiver Account / Wallet Number
                  </label>
                  <input
                    type="text"
                    value={payoutReference}
                    onChange={(e) => setPayoutReference(e.target.value)}
                    placeholder="e.g. Bank account or Pay wallet number"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                  />
                </div>
              )}
            </div>

          </div>

          {/* Financial Amounts & Calculation Grid */}
          <div className="bg-emerald-50/40 p-4 rounded-lg border border-emerald-200/80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5">
                <Calculator className="w-4 h-4 text-emerald-700" />
                Financial Calculation & Currency Conversion
              </span>
              <div className="text-xs text-emerald-800 font-medium">
                {feeMode === 'sender_pays_extra' ? t.senderPaysFee : t.deductFromAmount}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Transfer Amount */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.transferAmount} *
                </label>
                <div className="flex">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={sendAmount || ''}
                    onChange={(e) => handleAmountChange(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-1.5 text-xs font-mono-numbers bg-white border border-slate-300 rounded-l-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                  />
                  <select
                    value={sendCurrency}
                    onChange={(e) => handleSendCurrencyChange(e.target.value)}
                    className="px-2 py-1.5 text-xs bg-slate-100 border border-l-0 border-slate-300 rounded-r-lg font-bold text-slate-700"
                  >
                    {currencies.map(c => (
                      <option key={c.code} value={c.code}>{c.code}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Service Fee */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.serviceFee} ({sendCurrency}) *
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  required
                  value={serviceFee}
                  onChange={(e) => setServiceFee(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full px-3 py-1.5 text-xs font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              {/* Payout Currency & Exchange Rate */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Receiver Currency
                </label>
                <select
                  value={payoutCurrency}
                  onChange={(e) => handlePayoutCurrencyChange(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-medium"
                >
                  {currencies.map(c => (
                    <option key={c.code} value={c.code}>{c.name} ({c.code})</option>
                  ))}
                </select>
              </div>

              {/* Exchange Rate */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.exchangeRate} (1 {sendCurrency} =)
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  required
                  value={exchangeRate || ''}
                  onChange={(e) => setExchangeRate(Math.max(0.000001, parseFloat(e.target.value) || 1.0))}
                  className="w-full px-3 py-1.5 text-xs font-mono-numbers bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

            </div>

            {/* Fee Mode Toggle */}
            <div className="flex items-center gap-4 text-xs">
              <span className="font-medium text-slate-700">{t.feeMode}:</span>
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="radio"
                  name="feeMode"
                  value="sender_pays_extra"
                  checked={feeMode === 'sender_pays_extra'}
                  onChange={() => setFeeMode('sender_pays_extra')}
                  className="text-emerald-700 focus:ring-emerald-500"
                />
                <span className="text-slate-700">{t.senderPaysFee}</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="radio"
                  name="feeMode"
                  value="deduct_from_amount"
                  checked={feeMode === 'deduct_from_amount'}
                  onChange={() => setFeeMode('deduct_from_amount')}
                  className="text-emerald-700 focus:ring-emerald-500"
                />
                <span className="text-slate-700">{t.deductFromAmount}</span>
              </label>
            </div>

            {/* Calculation Result Callout */}
            <div className="p-3 bg-white rounded-lg border border-emerald-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-[11px] text-slate-500 block">{t.totalCollected}</span>
                <span className="font-mono-numbers text-sm font-bold text-slate-900">
                  {formatCurrency(totalCollected, sendCurrency)}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  ({sendCurrency === 'MMK' ? 'Cash/Wallet Collected' : 'Foreign Inflow'})
                </span>
              </div>

              <div>
                <span className="text-[11px] text-slate-500 block">{t.payoutAmount}</span>
                <span className="font-mono-numbers text-sm font-bold text-emerald-800">
                  {formatCurrency(payoutAmount, payoutCurrency)}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  (Payable to Receiver)
                </span>
              </div>

              <div>
                <span className="text-[11px] text-slate-500 block">{t.serviceFee} (Business Revenue)</span>
                <span className="font-mono-numbers text-sm font-bold text-slate-900">
                  {formatCurrency(serviceFee, sendCurrency)}
                </span>
                <span className="text-[10px] text-emerald-600 block mt-0.5 font-medium">
                  Recorded as Gross Income
                </span>
              </div>
            </div>

          </div>

          {/* Status & Remarks */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {t.status}
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as TransferStatus)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-medium"
              >
                <option value="completed">{t.completed} (Cash handed / Payout issued)</option>
                <option value="pending">{t.pending} (Awaiting receiver collection)</option>
                <option value="processing">{t.processing} (In transit / Bank clearing)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {t.notes}
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t.notesPlaceholder}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
              />
            </div>
          </div>

          {/* Editing Reason Required if Updating */}
          {editingTransfer && (
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 space-y-1">
              <label className="block text-xs font-bold text-amber-900">
                {t.reversalReasonPrompt} *
              </label>
              <input
                type="text"
                required
                value={editReason}
                onChange={(e) => setEditReason(e.target.value)}
                placeholder="State why this completed transaction is being modified..."
                className="w-full px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600"
              />
            </div>
          )}

          {/* Actions Bar */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              {editingTransfer ? t.updateTransferBtn : t.createTransferBtn}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

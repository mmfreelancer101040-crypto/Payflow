import React, { useState, useMemo } from 'react';
import { MoneyTransfer, TransferStatus, User } from '../types';
import { Language, translations } from '../utils/i18n';
import { formatCurrency, formatNumberOnly } from '../utils/financialCalculations';
import { 
  Search, 
  Filter, 
  PlusCircle, 
  Printer, 
  Edit2, 
  Undo2, 
  Ban, 
  Download, 
  CheckCircle,
  Eye,
  Calendar,
  X
} from 'lucide-react';

interface TransfersViewProps {
  transfers: MoneyTransfer[];
  currentUser: User;
  language: Language;
  onOpenNewTransfer: () => void;
  onEditTransfer: (t: MoneyTransfer) => void;
  onPrintTransfer: (t: MoneyTransfer) => void;
  onCancelTransfer: (t: MoneyTransfer) => void;
  onRefundTransfer: (t: MoneyTransfer) => void;
  onQuickComplete: (id: string) => void;
  onViewDetails: (t: MoneyTransfer) => void;
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  transfers,
  currentUser,
  language,
  onOpenNewTransfer,
  onEditTransfer,
  onPrintTransfer,
  onCancelTransfer,
  onRefundTransfer,
  onQuickComplete,
  onViewDetails,
}) => {
  const t = translations[language];

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');

  const filteredTransfers = useMemo(() => {
    return transfers.filter((item) => {
      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesId = item.id.toLowerCase().includes(query);
        const matchesSender = item.senderName.toLowerCase().includes(query) || item.senderPhone.includes(query);
        const matchesReceiver = item.receiverName.toLowerCase().includes(query) || item.receiverPhone.includes(query);
        const matchesLocation = item.senderLocation.toLowerCase().includes(query) || item.receiverLocation.toLowerCase().includes(query);
        const matchesNotes = item.notes?.toLowerCase().includes(query);
        if (!matchesId && !matchesSender && !matchesReceiver && !matchesLocation && !matchesNotes) {
          return false;
        }
      }

      // Status
      if (statusFilter !== 'all' && item.status !== statusFilter) {
        return false;
      }

      // Payment method
      if (paymentFilter !== 'all' && item.paymentMethod !== paymentFilter) {
        return false;
      }

      // Date
      if (dateFilter && !item.date.startsWith(dateFilter)) {
        return false;
      }

      return true;
    });
  }, [transfers, searchTerm, statusFilter, paymentFilter, dateFilter]);

  // CSV Export
  const handleExportCsv = () => {
    const headers = [
      'Transaction ID',
      'Date & Time',
      'Sender Name',
      'Sender Phone',
      'Sender Location',
      'Receiver Name',
      'Receiver Phone',
      'Receiver Location',
      'Send Amount',
      'Send Currency',
      'Exchange Rate',
      'Payout Amount',
      'Payout Currency',
      'Service Fee',
      'Total Collected',
      'Payment Method',
      'Payout Method',
      'Status',
      'Handled By',
      'Notes'
    ];

    const rows = filteredTransfers.map(item => [
      item.id,
      item.date,
      `"${item.senderName.replace(/"/g, '""')}"`,
      `"${item.senderPhone}"`,
      `"${item.senderLocation.replace(/"/g, '""')}"`,
      `"${item.receiverName.replace(/"/g, '""')}"`,
      `"${item.receiverPhone}"`,
      `"${item.receiverLocation.replace(/"/g, '""')}"`,
      item.sendAmount,
      item.sendCurrency,
      item.exchangeRate,
      item.payoutAmount,
      item.payoutCurrency,
      item.serviceFee,
      item.totalCollectedFromSender,
      item.paymentMethod,
      item.payoutMethod,
      item.status,
      `"${item.handledByStaffName.replace(/"/g, '""')}"`,
      `"${(item.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SwiftRemit_Transfers_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {t.transfers}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track, search, and manage customer remittance records ({transfers.length} total)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={onOpenNewTransfer}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.newTransfer}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.search}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50/60 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 focus:bg-white"
            />
            {searchTerm && (
              <button 
                type="button"
                onClick={() => setSearchTerm('')} 
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50/60 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            >
              <option value="all">{t.all} Statuses</option>
              <option value="completed">{t.completed}</option>
              <option value="pending">{t.pending}</option>
              <option value="processing">{t.processing}</option>
              <option value="refunded">{t.refunded}</option>
              <option value="cancelled">{t.cancelled}</option>
            </select>
          </div>

          {/* Payment Method Filter */}
          <div>
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50/60 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            >
              <option value="all">{t.all} Channels</option>
              <option value="cash">{t.cash}</option>
              <option value="kbz_pay">{t.kbz_pay}</option>
              <option value="wave_pay">{t.wave_pay}</option>
              <option value="kbz_bank">{t.kbz_bank}</option>
              <option value="aya_bank">{t.aya_bank}</option>
              <option value="cb_bank">{t.cb_bank}</option>
              <option value="bank_transfer">{t.bank_transfer}</option>
            </select>
          </div>

          {/* Date Picker Filter */}
          <div className="relative">
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50/60 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            />
            {dateFilter && (
              <button
                type="button"
                onClick={() => setDateFilter('')}
                className="absolute right-2 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
          </div>

        </div>

        {/* Filter Summary */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <span>Showing <strong>{filteredTransfers.length}</strong> of {transfers.length} records</span>
          {(searchTerm || statusFilter !== 'all' || paymentFilter !== 'all' || dateFilter) && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
                setPaymentFilter('all');
                setDateFilter('');
              }}
              className="text-emerald-700 hover:underline font-medium cursor-pointer"
            >
              Reset all filters
            </button>
          )}
        </div>
      </div>

      {/* Main Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/70 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">TXN ID</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Sender Details</th>
                <th className="py-3 px-4">Receiver Details</th>
                <th className="py-3 px-4 text-right">Transfer Amount</th>
                <th className="py-3 px-4 text-right">Fee</th>
                <th className="py-3 px-4 text-right">Collected</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right no-print">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransfers.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-500 text-xs">
                    No money transfers match your current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredTransfers.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                    
                    {/* ID */}
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onViewDetails(item)}
                        className="hover:underline text-left cursor-pointer"
                        title="Click to view full transaction ledger details"
                      >
                        {item.id}
                      </button>
                    </td>

                    {/* Date */}
                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                      <div>{item.date.slice(0, 10)}</div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </td>

                    {/* Sender */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{item.senderName}</div>
                      <div className="text-[10px] text-slate-400">{item.senderPhone || '-'}</div>
                      <div className="text-[10px] text-slate-500">{item.senderLocation}</div>
                    </td>

                    {/* Receiver */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{item.receiverName}</div>
                      <div className="text-[10px] text-slate-400">{item.receiverPhone || '-'}</div>
                      <div className="text-[10px] text-slate-500">{item.receiverLocation}</div>
                    </td>

                    {/* Transfer Amount */}
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                      {formatCurrency(item.sendAmount, item.sendCurrency)}
                    </td>

                    {/* Fee */}
                    <td className="py-3 px-4 text-right font-mono text-emerald-700 whitespace-nowrap font-medium">
                      +{formatCurrency(item.serviceFee, item.sendCurrency)}
                    </td>

                    {/* Total Collected */}
                    <td className="py-3 px-4 text-right font-mono text-slate-900 whitespace-nowrap font-semibold">
                      {formatCurrency(item.totalCollectedFromSender, item.sendCurrency)}
                    </td>

                    {/* Payment Method */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-medium text-slate-700 block">
                        {item.paymentMethod.toUpperCase()}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Payout: {item.payoutMethod.toUpperCase()}
                      </span>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        item.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : item.status === 'processing'
                          ? 'bg-blue-100 text-blue-800'
                          : item.status === 'refunded'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {item.status}
                      </span>
                    </td>

                    {/* Action Buttons */}
                    <td className="py-3 px-4 text-right whitespace-nowrap no-print">
                      <div className="flex items-center justify-end gap-1">
                        
                        {/* Quick Complete if Pending/Processing */}
                        {(item.status === 'pending' || item.status === 'processing') && (
                          <button
                            type="button"
                            onClick={() => onQuickComplete(item.id)}
                            title="Mark as Completed (Payout handed to receiver)"
                            className="p-1 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                        )}

                        {/* Print Receipt */}
                        <button
                          type="button"
                          onClick={() => onPrintTransfer(item)}
                          title="Print Receipt"
                          className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        {/* View Details */}
                        <button
                          type="button"
                          onClick={() => onViewDetails(item)}
                          title="View Details"
                          className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Edit (Admin only or if authorized) */}
                        {(currentUser.role === 'admin' || currentUser.permissions.canEditTransactions) && item.status !== 'cancelled' && (
                          <button
                            type="button"
                            onClick={() => onEditTransfer(item)}
                            title="Edit Transfer"
                            className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}

                        {/* Refund if Completed/Processing */}
                        {(currentUser.role === 'admin' || currentUser.permissions.canCancelOrRefund) && item.status === 'completed' && (
                          <button
                            type="button"
                            onClick={() => onRefundTransfer(item)}
                            title="Process Refund"
                            className="p-1 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded cursor-pointer"
                          >
                            <Undo2 className="w-4 h-4" />
                          </button>
                        )}

                        {/* Cancel if Pending/Processing */}
                        {(currentUser.role === 'admin' || currentUser.permissions.canCancelOrRefund) && (item.status === 'pending' || item.status === 'processing') && (
                          <button
                            type="button"
                            onClick={() => onCancelTransfer(item)}
                            title="Cancel Transaction"
                            className="p-1 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded cursor-pointer"
                          >
                            <Ban className="w-4 h-4" />
                          </button>
                        )}

                      </div>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export type UserRole = 'admin' | 'staff';

export interface UserPermissions {
  canEditTransactions: boolean;
  canCancelOrRefund: boolean;
  canManageUsers: boolean;
  canViewAuditLogs: boolean;
  canManageCashReconciliation: boolean;
  canManageExpenses: boolean;
  canExportData: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  passwordHash?: string; // Stored safely
  permissions: UserPermissions;
  isActive: boolean;
  createdAt: string;
}

export type TransferStatus = 'pending' | 'processing' | 'completed' | 'cancelled' | 'refunded';

export type PaymentMethod = 
  | 'cash'
  | 'kbz_pay'
  | 'wave_pay'
  | 'kbz_bank'
  | 'aya_bank'
  | 'cb_bank'
  | 'bank_transfer'
  | 'mobile_wallet'
  | 'other';

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  rateToBase: number; // e.g. 1 USD = 3500 MMK, or relative to base
  decimals: number;
}

export interface MoneyTransfer {
  id: string; // Auto-generated e.g. TRF-20261013-0001
  date: string; // ISO datetime
  senderName: string;
  senderPhone: string;
  senderLocation: string;
  receiverName: string;
  receiverPhone: string;
  receiverLocation: string;
  
  // Financial amounts
  sendAmount: number;
  sendCurrency: string;
  payoutAmount: number;
  payoutCurrency: string;
  exchangeRate: number; // e.g. 1 sendCurrency = X payoutCurrency
  serviceFee: number; // Business revenue / commission
  feePaymentMode: 'sender_pays_extra' | 'deduct_from_amount';
  totalCollectedFromSender: number; // sendAmount + serviceFee (or sendAmount if fee deducted)
  amountToBePaidToReceiver: number;
  
  // Channels & Handling
  paymentMethod: PaymentMethod;
  payoutMethod: PaymentMethod;
  paymentReference?: string;
  payoutReference?: string;
  status: TransferStatus;
  handledByStaffName: string;
  handledByStaffId: string;
  notes?: string;
  
  // Reversal / Cancellation / Refund records
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledByStaffName?: string;
  cancelledByStaffId?: string;
  
  refundStatus?: 'none' | 'full' | 'partial';
  refundAmount?: number;
  refundFeeRetained?: number;
  refundReason?: string;
  refundedAt?: string;
  refundedByStaffName?: string;

  createdAt: string;
  updatedAt: string;
  updatedByStaffName?: string;
}

export type ExpenseCategory = 
  | 'rent'
  | 'salaries'
  | 'electricity'
  | 'internet_phone'
  | 'transportation'
  | 'office_supplies'
  | 'refreshments'
  | 'tax_fees'
  | 'maintenance'
  | 'miscellaneous';

export interface BusinessExpense {
  id: string;
  date: string;
  category: ExpenseCategory;
  amount: number;
  currency: string;
  paymentMethod: PaymentMethod;
  description: string;
  recordedByStaffName: string;
  recordedByStaffId: string;
  receiptNumber?: string;
  notes?: string;
  createdAt: string;
}

export type CashMovementType = 
  | 'bank_deposit'       // Cash in drawer deposited into Bank account
  | 'bank_withdrawal'    // Cash withdrawn from Bank into drawer
  | 'owner_capital_in'   // Capital injected into cash drawer
  | 'owner_drawing';     // Owner drawing from cash drawer

export interface CashMovement {
  id: string;
  date: string;
  type: CashMovementType;
  amount: number;
  currency: string;
  bankAccountOrSource: string;
  referenceNumber?: string;
  description: string;
  recordedByStaffName: string;
  createdAt: string;
}

export interface CashReconciliation {
  id: string;
  date: string; // YYYY-MM-DD
  openingBalance: number;
  cashReceivedToday: number;
  cashPaidOutToday: number;
  cashFeesReceivedToday: number;
  cashExpensesPaidToday: number;
  bankDepositsFromCash: number;
  bankWithdrawalsToCash: number;
  expectedClosingCash: number;
  actualCountedCash: number;
  variance: number; // actual - expected
  denominationBreakdown?: Record<string, number>;
  notes: string;
  reconciledByStaffName: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: 'CREATE' | 'UPDATE' | 'CANCEL' | 'REFUND' | 'DELETE_ATTEMPT' | 'EXPENSE' | 'RECONCILIATION' | 'BACKUP' | 'RESTORE' | 'LOGIN' | 'LOGOUT';
  entityType: 'transfer' | 'expense' | 'reconciliation' | 'user' | 'settings' | 'auth';
  entityId: string;
  details: string;
  previousState?: string;
  newState?: string;
}

export interface BusinessProfile {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  secondaryPhone?: string;
  email: string;
  licenseNumber: string;
  baseCurrency: string;
  logoUrl: string;
  receiptFooterNote: string;
  receiptTerms: string;
  taxNumber?: string;
  branchName: string;
}

export interface DailySummaryData {
  date: string;
  totalTransfersCount: number;
  completedCount: number;
  pendingCount: number;
  cancelledCount: number;
  refundedCount: number;
  
  // Gross Volume Transferred
  totalTransferVolume: number;
  
  // Inflows & Outflows
  totalMoneyReceived: number; // Actual money incoming (send amounts + fees)
  totalMoneyPaidOut: number;  // Actual money handed to receivers
  
  // Business Profitability
  totalServiceFeesEarned: number; // Business revenue
  totalBusinessExpenses: number;
  netProfit: number; // Fees - Expenses
  
  // Cash in Register Metrics
  openingCashBalance: number;
  netCashFlowToday: number;
  closingCashBalance: number;
  
  // Bank balances & Pending Liabilities
  pendingPayoutLiabilities: number; // Money collected but not yet paid to receiver
  reconciledRecord?: CashReconciliation;
}

export interface MonthlySummaryData {
  month: string; // YYYY-MM
  monthName: string;
  totalTransfersCount: number;
  completedCount: number;
  pendingCount: number;
  cancelledCount: number;
  refundedCount: number;
  
  totalTransferVolume: number;
  totalMoneyReceived: number;
  totalMoneyPaidOut: number;
  totalServiceFeesEarned: number;
  totalBusinessExpenses: number;
  netProfit: number;
  
  dailyBreakdown: Array<{
    date: string;
    transfersCount: number;
    volume: number;
    fees: number;
    expenses: number;
    netProfit: number;
  }>;
}

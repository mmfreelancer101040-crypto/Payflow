import { 
  MoneyTransfer, 
  BusinessExpense, 
  CashMovement, 
  CashReconciliation, 
  DailySummaryData, 
  MonthlySummaryData 
} from '../types';

/**
 * Decimal-safe rounding to prevent floating-point inaccuracies
 */
export function roundTo(val: number, decimals: number = 2): number {
  const factor = Math.pow(10, decimals);
  return Math.round((val + Number.EPSILON) * factor) / factor;
}

export function formatCurrency(amount: number, currency: string = 'MMK'): string {
  const rounded = roundTo(amount, 2);
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: currency === 'MMK' ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(rounded);

  return `${formatted} ${currency}`;
}

export function formatNumberOnly(amount: number, decimals: number = 2): string {
  const rounded = roundTo(amount, decimals);
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals === 0 ? 0 : decimals,
    maximumFractionDigits: decimals,
  }).format(rounded);
}

/**
 * Calculates financial amounts for a transfer
 */
export function calculateTransferFinancials(
  sendAmount: number,
  serviceFee: number,
  exchangeRate: number,
  feeMode: 'sender_pays_extra' | 'deduct_from_amount'
): {
  totalCollected: number;
  payoutAmount: number;
} {
  const safeSend = roundTo(Math.max(0, sendAmount));
  const safeFee = roundTo(Math.max(0, serviceFee));
  const safeRate = exchangeRate > 0 ? exchangeRate : 1.0;

  if (feeMode === 'sender_pays_extra') {
    const totalCollected = roundTo(safeSend + safeFee);
    const payoutAmount = roundTo(safeSend * safeRate);
    return { totalCollected, payoutAmount };
  } else {
    // Fee is deducted from the send amount
    const netSend = roundTo(Math.max(0, safeSend - safeFee));
    const totalCollected = safeSend;
    const payoutAmount = roundTo(netSend * safeRate);
    return { totalCollected, payoutAmount };
  }
}

/**
 * Checks if a transaction date falls on a given YYYY-MM-DD
 */
export function isSameDate(isoDateTime: string, targetDateStr: string): boolean {
  if (!isoDateTime) return false;
  return isoDateTime.startsWith(targetDateStr);
}

/**
 * Checks if a transaction date falls in a given YYYY-MM
 */
export function isSameMonth(isoDateTime: string, targetMonthStr: string): boolean {
  if (!isoDateTime) return false;
  return isoDateTime.startsWith(targetMonthStr);
}

/**
 * Generates the Daily Financial Summary for a specific date (YYYY-MM-DD)
 */
export function generateDailySummary(
  targetDate: string,
  transfers: MoneyTransfer[],
  expenses: BusinessExpense[],
  cashMovements: CashMovement[],
  reconciliations: CashReconciliation[],
  defaultOpeningCash: number = 0
): DailySummaryData {
  const dayTransfers = transfers.filter(t => isSameDate(t.date, targetDate));
  const dayExpenses = expenses.filter(e => isSameDate(e.date, targetDate));
  const dayMovements = cashMovements.filter(m => isSameDate(m.date, targetDate));
  const dayReconciliation = reconciliations.find(r => r.date === targetDate);

  let totalTransferVolume = 0;
  let totalMoneyReceived = 0;
  let totalMoneyPaidOut = 0;
  let totalServiceFeesEarned = 0;
  let pendingPayoutLiabilities = 0;

  let completedCount = 0;
  let pendingCount = 0;
  let cancelledCount = 0;
  let refundedCount = 0;

  // Cash in drawer specific tracking
  let cashReceivedToday = 0;
  let cashPaidOutToday = 0;

  for (const t of dayTransfers) {
    if (t.status === 'completed') {
      completedCount++;
      totalTransferVolume = roundTo(totalTransferVolume + t.sendAmount);
      totalMoneyReceived = roundTo(totalMoneyReceived + t.totalCollectedFromSender);
      totalMoneyPaidOut = roundTo(totalMoneyPaidOut + t.payoutAmount);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + t.serviceFee);

      if (t.paymentMethod === 'cash') {
        cashReceivedToday = roundTo(cashReceivedToday + t.totalCollectedFromSender);
      }
      if (t.payoutMethod === 'cash') {
        cashPaidOutToday = roundTo(cashPaidOutToday + t.payoutAmount);
      }
    } else if (t.status === 'pending' || t.status === 'processing') {
      pendingCount++;
      // In pending state, money was collected from sender, but not yet paid to receiver
      totalTransferVolume = roundTo(totalTransferVolume + t.sendAmount);
      totalMoneyReceived = roundTo(totalMoneyReceived + t.totalCollectedFromSender);
      pendingPayoutLiabilities = roundTo(pendingPayoutLiabilities + t.payoutAmount);
      // Service fee is counted once transfer is initiated/completed
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + t.serviceFee);

      if (t.paymentMethod === 'cash') {
        cashReceivedToday = roundTo(cashReceivedToday + t.totalCollectedFromSender);
      }
    } else if (t.status === 'cancelled') {
      cancelledCount++;
      // Cancelled: no volume, no fees, no liability
    } else if (t.status === 'refunded') {
      refundedCount++;
      // Refunded: adjust if fee was retained or fully refunded
      const retainedFee = roundTo(t.refundFeeRetained || 0);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + retainedFee);
    }
  }

  // Calculate day expenses
  let totalBusinessExpenses = 0;
  let cashExpensesToday = 0;
  for (const exp of dayExpenses) {
    totalBusinessExpenses = roundTo(totalBusinessExpenses + exp.amount);
    if (exp.paymentMethod === 'cash') {
      cashExpensesToday = roundTo(cashExpensesToday + exp.amount);
    }
  }

  // Net Profit = Service fees earned minus Business expenses
  const netProfit = roundTo(totalServiceFeesEarned - totalBusinessExpenses);

  // Cash movement adjustments (Bank <-> Drawer)
  let bankDepositsFromCash = 0;
  let bankWithdrawalsToCash = 0;
  let ownerCapitalCash = 0;
  let ownerDrawingCash = 0;

  for (const m of dayMovements) {
    if (m.type === 'bank_deposit') {
      bankDepositsFromCash = roundTo(bankDepositsFromCash + m.amount);
    } else if (m.type === 'bank_withdrawal') {
      bankWithdrawalsToCash = roundTo(bankWithdrawalsToCash + m.amount);
    } else if (m.type === 'owner_capital_in') {
      ownerCapitalCash = roundTo(ownerCapitalCash + m.amount);
    } else if (m.type === 'owner_drawing') {
      ownerDrawingCash = roundTo(ownerDrawingCash + m.amount);
    }
  }

  // Determine opening balance (either from reconciliation of yesterday or default)
  const openingCashBalance = defaultOpeningCash;
  
  // Net cash flow in drawer
  const netCashFlowToday = roundTo(
    cashReceivedToday + bankWithdrawalsToCash + ownerCapitalCash -
    (cashPaidOutToday + cashExpensesToday + bankDepositsFromCash + ownerDrawingCash)
  );

  const closingCashBalance = roundTo(openingCashBalance + netCashFlowToday);

  return {
    date: targetDate,
    totalTransfersCount: dayTransfers.length,
    completedCount,
    pendingCount,
    cancelledCount,
    refundedCount,
    totalTransferVolume,
    totalMoneyReceived,
    totalMoneyPaidOut,
    totalServiceFeesEarned,
    totalBusinessExpenses,
    netProfit,
    openingCashBalance,
    netCashFlowToday,
    closingCashBalance,
    pendingPayoutLiabilities,
    reconciledRecord: dayReconciliation
  };
}

/**
 * Generates the Monthly Summary for a specific month (YYYY-MM)
 */
export function generateMonthlySummary(
  targetMonth: string,
  transfers: MoneyTransfer[],
  expenses: BusinessExpense[]
): MonthlySummaryData {
  const monthTransfers = transfers.filter(t => isSameMonth(t.date, targetMonth));
  const monthExpenses = expenses.filter(e => isSameMonth(e.date, targetMonth));

  let totalTransferVolume = 0;
  let totalMoneyReceived = 0;
  let totalMoneyPaidOut = 0;
  let totalServiceFeesEarned = 0;

  let completedCount = 0;
  let pendingCount = 0;
  let cancelledCount = 0;
  let refundedCount = 0;

  for (const t of monthTransfers) {
    if (t.status === 'completed') {
      completedCount++;
      totalTransferVolume = roundTo(totalTransferVolume + t.sendAmount);
      totalMoneyReceived = roundTo(totalMoneyReceived + t.totalCollectedFromSender);
      totalMoneyPaidOut = roundTo(totalMoneyPaidOut + t.payoutAmount);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + t.serviceFee);
    } else if (t.status === 'pending' || t.status === 'processing') {
      pendingCount++;
      totalTransferVolume = roundTo(totalTransferVolume + t.sendAmount);
      totalMoneyReceived = roundTo(totalMoneyReceived + t.totalCollectedFromSender);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + t.serviceFee);
    } else if (t.status === 'cancelled') {
      cancelledCount++;
    } else if (t.status === 'refunded') {
      refundedCount++;
      const retainedFee = roundTo(t.refundFeeRetained || 0);
      totalServiceFeesEarned = roundTo(totalServiceFeesEarned + retainedFee);
    }
  }

  const totalBusinessExpenses = roundTo(
    monthExpenses.reduce((sum, e) => sum + e.amount, 0)
  );

  const netProfit = roundTo(totalServiceFeesEarned - totalBusinessExpenses);

  // Group by day for the daily breakdown
  const dailyMap = new Map<string, { count: number; volume: number; fees: number; expenses: number }>();
  
  // Fill all unique days in the month present in transactions or expenses
  const [yearStr, mStr] = targetMonth.split('-');
  const daysInMonth = new Date(parseInt(yearStr, 10), parseInt(mStr, 10), 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = `${targetMonth}-${String(d).padStart(2, '0')}`;
    dailyMap.set(dayStr, { count: 0, volume: 0, fees: 0, expenses: 0 });
  }

  for (const t of monthTransfers) {
    if (t.status !== 'cancelled') {
      const day = t.date.slice(0, 10);
      const curr = dailyMap.get(day) || { count: 0, volume: 0, fees: 0, expenses: 0 };
      curr.count += 1;
      curr.volume = roundTo(curr.volume + t.sendAmount);
      curr.fees = roundTo(curr.fees + (t.status === 'refunded' ? (t.refundFeeRetained || 0) : t.serviceFee));
      dailyMap.set(day, curr);
    }
  }

  for (const e of monthExpenses) {
    const day = e.date.slice(0, 10);
    const curr = dailyMap.get(day) || { count: 0, volume: 0, fees: 0, expenses: 0 };
    curr.expenses = roundTo(curr.expenses + e.amount);
    dailyMap.set(day, curr);
  }

  const dailyBreakdown = Array.from(dailyMap.entries())
    .map(([date, data]) => ({
      date,
      transfersCount: data.count,
      volume: data.volume,
      fees: data.fees,
      expenses: data.expenses,
      netProfit: roundTo(data.fees - data.expenses),
    }))
    .sort((a, b) => a.date.localeCompare(b.date));

  const monthObj = new Date(parseInt(yearStr, 10), parseInt(mStr, 10) - 1, 1);
  const monthName = monthObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return {
    month: targetMonth,
    monthName,
    totalTransfersCount: monthTransfers.length,
    completedCount,
    pendingCount,
    cancelledCount,
    refundedCount,
    totalTransferVolume,
    totalMoneyReceived,
    totalMoneyPaidOut,
    totalServiceFeesEarned,
    totalBusinessExpenses,
    netProfit,
    dailyBreakdown,
  };
}

/**
 * Calculates current cash drawer balance across all history
 */
export function calculateCurrentCashDrawer(
  openingBalance: number,
  transfers: MoneyTransfer[],
  expenses: BusinessExpense[],
  cashMovements: CashMovement[]
): number {
  let cashIn = 0;
  let cashOut = 0;

  for (const t of transfers) {
    if (t.paymentMethod === 'cash' && (t.status === 'completed' || t.status === 'pending' || t.status === 'processing')) {
      cashIn = roundTo(cashIn + t.totalCollectedFromSender);
    }
    if (t.payoutMethod === 'cash' && t.status === 'completed') {
      cashOut = roundTo(cashOut + t.payoutAmount);
    }
    if (t.status === 'refunded' && t.refundAmount && t.paymentMethod === 'cash') {
      cashOut = roundTo(cashOut + t.refundAmount);
    }
  }

  for (const e of expenses) {
    if (e.paymentMethod === 'cash') {
      cashOut = roundTo(cashOut + e.amount);
    }
  }

  for (const m of cashMovements) {
    if (m.type === 'bank_deposit') {
      cashOut = roundTo(cashOut + m.amount);
    } else if (m.type === 'bank_withdrawal') {
      cashIn = roundTo(cashIn + m.amount);
    } else if (m.type === 'owner_capital_in') {
      cashIn = roundTo(cashIn + m.amount);
    } else if (m.type === 'owner_drawing') {
      cashOut = roundTo(cashOut + m.amount);
    }
  }

  return roundTo(openingBalance + cashIn - cashOut);
}

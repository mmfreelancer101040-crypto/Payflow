export type Language = 'en' | 'my';

export interface Translations {
  // Navigation & General
  appTitle: string;
  appSubtitle: string;
  dashboard: string;
  transfers: string;
  newTransfer: string;
  financialRecords: string;
  dailySummary: string;
  monthlySummary: string;
  expenses: string;
  cashReconciliation: string;
  auditLogs: string;
  settings: string;
  testSuite: string;
  logout: string;
  login: string;
  search: string;
  filter: string;
  all: string;
  status: string;
  date: string;
  actions: string;
  view: string;
  edit: string;
  cancel: string;
  refund: string;
  print: string;
  exportCsv: string;
  exportExcel: string;
  save: string;
  close: string;
  back: string;
  confirm: string;
  delete: string;
  reason: string;
  notes: string;
  admin: string;
  staff: string;
  role: string;
  
  // Dashboard KPI
  todayTransfers: string;
  todayVolume: string;
  todayServiceFees: string;
  todayReceived: string;
  todayPaidOut: string;
  todayPending: string;
  todayExpenses: string;
  todayNetProfit: string;
  monthlyVolume: string;
  monthlyFees: string;
  quickActions: string;
  recentTransfers: string;
  cashOnHand: string;
  pendingLiabilities: string;

  // Transfer Form & Details
  transactionId: string;
  dateTime: string;
  senderInfo: string;
  receiverInfo: string;
  senderName: string;
  senderPhone: string;
  senderLocation: string;
  receiverName: string;
  receiverPhone: string;
  receiverLocation: string;
  transferAmount: string;
  currency: string;
  exchangeRate: string;
  serviceFee: string;
  feeMode: string;
  senderPaysFee: string;
  deductFromAmount: string;
  totalCollected: string;
  payoutAmount: string;
  paymentMethod: string;
  payoutMethod: string;
  handler: string;
  notesPlaceholder: string;
  createTransferBtn: string;
  updateTransferBtn: string;
  reversalReasonPrompt: string;
  confirmCancelTransfer: string;
  confirmRefundTransfer: string;

  // Statuses
  pending: string;
  processing: string;
  completed: string;
  cancelled: string;
  refunded: string;

  // Payment Methods
  cash: string;
  kbz_pay: string;
  wave_pay: string;
  kbz_bank: string;
  aya_bank: string;
  cb_bank: string;
  bank_transfer: string;
  mobile_wallet: string;
  other: string;

  // Expenses & Cash
  addExpense: string;
  expenseCategory: string;
  expenseAmount: string;
  expenseDescription: string;
  cashMovements: string;
  bankDeposit: string;
  bankWithdrawal: string;
  ownerCapital: string;
  ownerDrawing: string;
  recordMovement: string;
  
  // Reconciliation
  reconciliationTitle: string;
  openingCashBalance: string;
  expectedClosingCash: string;
  actualCountedCash: string;
  cashVariance: string;
  balanced: string;
  cashSurplus: string;
  cashShortage: string;
  submitReconciliation: string;

  // Receipt
  receiptTitle: string;
  customerCopy: string;
  officeCopy: string;
  thermalReceipt: string;
  a4Receipt: string;
  authorizedSignature: string;
  customerSignature: string;
  thankYouMessage: string;

  // Financial Ledger
  fiduciaryNotice: string;
  passThroughExpl: string;
  businessIncomeExpl: string;
  openingBalance: string;
  closingBalance: string;
  netCashFlow: string;

  // Settings
  businessProfile: string;
  companyName: string;
  phone: string;
  address: string;
  licenseNo: string;
  userManagement: string;
  backupAndRestore: string;
  backupDownload: string;
  restoreUpload: string;
  complianceNotice: string;
  complianceWarning: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appTitle: 'SwiftRemit',
    appSubtitle: 'Money Transfer Management System',
    dashboard: 'Dashboard',
    transfers: 'Money Transfers',
    newTransfer: 'New Transfer',
    financialRecords: 'Financial Records',
    dailySummary: 'Daily Summary',
    monthlySummary: 'Monthly Summary',
    expenses: 'Expenses & Cash',
    cashReconciliation: 'Daily Cash Close',
    auditLogs: 'Audit Logs',
    settings: 'Settings & Users',
    testSuite: 'Financial Tests',
    logout: 'Log Out',
    login: 'Log In',
    search: 'Search by ID, sender, receiver, phone...',
    filter: 'Filter',
    all: 'All',
    status: 'Status',
    date: 'Date',
    actions: 'Actions',
    view: 'View',
    edit: 'Edit',
    cancel: 'Cancel',
    refund: 'Refund',
    print: 'Print Receipt',
    exportCsv: 'Export CSV',
    exportExcel: 'Export Excel',
    save: 'Save Changes',
    close: 'Close',
    back: 'Back',
    confirm: 'Confirm',
    delete: 'Delete',
    reason: 'Reason',
    notes: 'Notes / Remarks',
    admin: 'Admin',
    staff: 'Staff',
    role: 'Role',

    todayTransfers: "Today's Transfers",
    todayVolume: 'Volume Transferred Today',
    todayServiceFees: 'Service Fees Earned',
    todayReceived: 'Total Money Received',
    todayPaidOut: 'Total Money Paid Out',
    todayPending: 'Pending Transfers',
    todayExpenses: 'Business Expenses',
    todayNetProfit: 'Daily Net Profit',
    monthlyVolume: 'Monthly Transfer Volume',
    monthlyFees: 'Monthly Service Fees',
    quickActions: 'Quick Actions',
    recentTransfers: 'Recent Transfers',
    cashOnHand: 'Cash in Drawer',
    pendingLiabilities: 'Pending Payout Obligations',

    transactionId: 'Transaction ID',
    dateTime: 'Date & Time',
    senderInfo: 'Sender Information',
    receiverInfo: 'Receiver Information',
    senderName: 'Sender Name',
    senderPhone: 'Sender Phone',
    senderLocation: 'Sender Location / Branch',
    receiverName: 'Receiver Name',
    receiverPhone: 'Receiver Phone',
    receiverLocation: 'Receiver Location / Destination',
    transferAmount: 'Transfer Amount',
    currency: 'Currency',
    exchangeRate: 'Exchange Rate',
    serviceFee: 'Service Fee / Commission',
    feeMode: 'Fee Calculation',
    senderPaysFee: 'Sender pays fee on top (Amount + Fee)',
    deductFromAmount: 'Fee deducted from amount (Amount - Fee)',
    totalCollected: 'Total Collected from Sender',
    payoutAmount: 'Amount Payable to Receiver',
    paymentMethod: 'Sender Payment Method',
    payoutMethod: 'Payout Method to Receiver',
    handler: 'Handled By (Staff)',
    notesPlaceholder: 'Enter any special instructions, reference numbers or ID notes...',
    createTransferBtn: 'Record & Issue Transfer',
    updateTransferBtn: 'Update Transaction',
    reversalReasonPrompt: 'Reason for cancellation or reversal (Required)',
    confirmCancelTransfer: 'Confirm Transaction Cancellation',
    confirmRefundTransfer: 'Confirm Transaction Refund',

    pending: 'Pending',
    processing: 'Processing',
    completed: 'Completed',
    cancelled: 'Cancelled',
    refunded: 'Refunded',

    cash: 'Cash',
    kbz_pay: 'KPay (KBZPay)',
    wave_pay: 'WavePay',
    kbz_bank: 'KBZ Bank Account',
    aya_bank: 'AYA Bank Account',
    cb_bank: 'CB Bank Account',
    bank_transfer: 'Other Bank Transfer',
    mobile_wallet: 'Mobile Wallet',
    other: 'Other Channel',

    addExpense: 'Add Business Expense',
    expenseCategory: 'Expense Category',
    expenseAmount: 'Expense Amount',
    expenseDescription: 'Expense Description',
    cashMovements: 'Cash & Bank Movements',
    bankDeposit: 'Cash Deposit to Bank',
    bankWithdrawal: 'Bank Withdrawal to Cash',
    ownerCapital: 'Owner Capital Deposit',
    ownerDrawing: 'Owner Drawing / Withdrawal',
    recordMovement: 'Record Movement',

    reconciliationTitle: 'End-of-Day Cash Reconciliation',
    openingCashBalance: 'Opening Cash Balance',
    expectedClosingCash: 'System Expected Cash in Drawer',
    actualCountedCash: 'Physical Cash Counted',
    cashVariance: 'Cash Balance Variance',
    balanced: 'Perfect Match (Balanced)',
    cashSurplus: 'Surplus (+ Extra Cash)',
    cashShortage: 'Shortage (- Missing Cash)',
    submitReconciliation: 'Save & Close Day Reconciliation',

    receiptTitle: 'Official Money Transfer Receipt',
    customerCopy: 'Customer Copy',
    officeCopy: 'Office / Branch Copy',
    thermalReceipt: 'POS Thermal (80mm)',
    a4Receipt: 'Standard A4 Document',
    authorizedSignature: 'Authorized Staff Signature',
    customerSignature: 'Customer Signature',
    thankYouMessage: 'Thank you for choosing our money transfer services.',

    fiduciaryNotice: 'Financial Accounting Separation Notice',
    passThroughExpl: 'Pass-through funds (transfers collected and delivered) belong to customers and are fiduciary flow, NOT business profit.',
    businessIncomeExpl: 'Actual business revenue consists strictly of Service Fees and commissions earned, minus operational business expenses.',
    openingBalance: 'Opening Balance',
    closingBalance: 'Closing Balance',
    netCashFlow: 'Net Daily Cash Flow',

    businessProfile: 'Business Profile & Branding',
    companyName: 'Business / Agency Name',
    phone: 'Phone Number',
    address: 'Business Address',
    licenseNo: 'Remittance License / Registration No.',
    userManagement: 'Staff & Roles Management',
    backupAndRestore: 'Data Backup & Restore',
    backupDownload: 'Export Backup (JSON File)',
    restoreUpload: 'Restore From Backup (JSON File)',
    complianceNotice: 'Regulatory & Compliance Disclosure',
    complianceWarning: 'This system is an operational bookkeeping and management platform. Proper legal licenses, AML/KYC procedures, and regulatory compliance are required in accordance with local financial authorities.'
  },
  my: {
    appTitle: 'ဆွစ်ဖ်ရီမစ် (SwiftRemit)',
    appSubtitle: 'ငွေလွှဲလုပ်ငန်းစီမံခန့်ခွဲမှုစနစ်',
    dashboard: 'ပင်မစာမျက်နှာ',
    transfers: 'ငွေလွှဲမှတ်တမ်းများ',
    newTransfer: 'ငွေလွှဲအသစ်ထည့်ရန်',
    financialRecords: 'ဘဏ္ဍာရေးစာရင်းအသေးစိတ်',
    dailySummary: 'နေ့စဉ်အစီရင်ခံစာ',
    monthlySummary: 'လစဉ်အစီရင်ခံစာ',
    expenses: 'အသုံးစရိတ်နှင့် ငွေစာရင်း',
    cashReconciliation: 'နေ့စဉ်လက်ကျန်ငွေစစ်ဆေးခြင်း',
    auditLogs: 'လုပ်ဆောင်ချက်မှတ်တမ်း',
    settings: 'ဆက်တင်နှင့် အသုံးပြုသူများ',
    testSuite: 'တွက်ချက်မှုစစ်ဆေးချက်',
    logout: 'အကောင့်ထွက်ရန်',
    login: 'အကောင့်ဝင်ရန်',
    search: 'ဘောက်ချာနံပါတ်၊ ပို့သူ၊ လက်ခံသူ၊ ဖုန်းဖြင့်ရှာရန်...',
    filter: 'စစ်ထုတ်ရန်',
    all: 'အားလုံး',
    status: 'အခြေအနေ',
    date: 'ရက်စွဲ',
    actions: 'လုပ်ဆောင်ချက်',
    view: 'ကြည့်ရှုရန်',
    edit: 'ပြင်ဆင်ရန်',
    cancel: 'ပယ်ဖျက်ရန်',
    refund: 'ငွေပြန်အမ်းရန်',
    print: 'ဘောက်ချာထုတ်ရန်',
    exportCsv: 'CSV ဒေါင်းလုဒ်',
    exportExcel: 'Excel ဒေါင်းလုဒ်',
    save: 'သိမ်းဆည်းရန်',
    close: 'ပိတ်ရန်',
    back: 'ရှေ့သို့ပြန်သွားရန်',
    confirm: 'အတည်ပြုရန်',
    delete: 'ဖျက်ရန်',
    reason: 'အကြောင်းပြချက်',
    notes: 'မှတ်ချက်',
    admin: 'မန်နေဂျာ (Admin)',
    staff: 'စာရေးဝန်ထမ်း (Staff)',
    role: 'ရာထူး',

    todayTransfers: 'ယနေ့ငွေလွှဲအရေအတွက်',
    todayVolume: 'ယနေ့လွှဲပြောင်းငွေပမာဏ',
    todayServiceFees: 'ယနေ့ရရှိသော ဝန်ဆောင်ခ',
    todayReceived: 'ယနေ့လက်ခံရရှိငွေစုစုပေါင်း',
    todayPaidOut: 'ယနေ့ထုတ်ပေးပြီးငွေစုစုပေါင်း',
    todayPending: 'ဆိုင်းငံ့ငွေလွှဲများ',
    todayExpenses: 'ယနေ့လုပ်ငန်းကုန်ကျစရိတ်',
    todayNetProfit: 'ယနေ့အသားတင်အမြတ်',
    monthlyVolume: 'လစဉ်ငွေလွှဲပမာဏ',
    monthlyFees: 'လစဉ်ဝန်ဆောင်ခဝင်ငွေ',
    quickActions: 'အမြန်လုပ်ဆောင်ချက်များ',
    recentTransfers: 'လတ်တလော ငွေလွှဲများ',
    cashOnHand: 'လက်ရှိလက်ကျန်ငွေ',
    pendingLiabilities: 'ပေးချေရန်ကျန်ရှိသော ငွေပမာဏ',

    transactionId: 'လွှဲပြောင်းမှုနံပါတ်',
    dateTime: 'ရက်စွဲနှင့် အချိန်',
    senderInfo: 'ငွေပို့သူ အချက်အလက်',
    receiverInfo: 'ငွေလက်ခံသူ အချက်အလက်',
    senderName: 'ငွေပို့သူအမည်',
    senderPhone: 'ငွေပို့သူ ဖုန်းနံပါတ်',
    senderLocation: 'ပို့သည့်မြို့/ဌာနခွဲ',
    receiverName: 'ငွေလက်ခံသူအမည်',
    receiverPhone: 'ငွေလက်ခံသူ ဖုန်းနံပါတ်',
    receiverLocation: 'လက်ခံမည့်မြို့/နေရာ',
    transferAmount: 'လွှဲငွေပမာဏ',
    currency: 'ငွေကြေးအမျိုးအစား',
    exchangeRate: 'ငွေလဲလှယ်နှုန်း',
    serviceFee: 'ဝန်ဆောင်ခ/ကော်မရှင်',
    feeMode: 'ဝန်ဆောင်ခကောက်ခံပုံ',
    senderPaysFee: 'ပို့သူမှ ဝန်ဆောင်ခသီးသန့်ပေးသည် (လွှဲငွေ + ဝန်ဆောင်ခ)',
    deductFromAmount: 'လွှဲငွေထဲမှ ဝန်ဆောင်ခနုတ်သည် (လွှဲငွေ - ဝန်ဆောင်ခ)',
    totalCollected: 'ပို့သူထံမှ ကောက်ခံငွေစုစုပေါင်း',
    payoutAmount: 'ထုတ်ပေးရမည့် ငွေပမာဏ',
    paymentMethod: 'ငွေပေးချေသည့်နည်းလမ်း',
    payoutMethod: 'ထုတ်ပေးမည့်နည်းလမ်း',
    handler: 'တာဝန်ခံဝန်ထမ်း',
    notesPlaceholder: 'အခြားအထူးညွှန်ကြားချက် သို့မဟုတ် မှတ်ချက်ရေးပါ...',
    createTransferBtn: 'ငွေလွှဲမှတ်တမ်းတင်ပြီး ဘောက်ချာထုတ်မည်',
    updateTransferBtn: 'မှတ်တမ်းပြင်ဆင်မည်',
    reversalReasonPrompt: 'ပယ်ဖျက်ရသည့် အကြောင်းပြချက် (မဖြစ်မနေထည့်ရန်)',
    confirmCancelTransfer: 'ငွေလွှဲပယ်ဖျက်ခြင်း အတည်ပြုပါ',
    confirmRefundTransfer: 'ငွေပြန်အမ်းခြင်း အတည်ပြုပါ',

    pending: 'ဆိုင်းငံ့ထားဆဲ',
    processing: 'ဆောင်ရွက်နေဆဲ',
    completed: 'အောင်မြင်ပြီး',
    cancelled: 'ပယ်ဖျက်ပြီး',
    refunded: 'ငွေပြန်အမ်းပြီး',

    cash: 'လက်ငင်းငွေသား (Cash)',
    kbz_pay: 'ကေပေး (KBZPay)',
    wave_pay: 'ဝေ့ဗ်ပေး (WavePay)',
    kbz_bank: 'ကမ္ဘောဇဘဏ် (KBZ Bank)',
    aya_bank: 'ဧရာဝတီဘဏ် (AYA Bank)',
    cb_bank: 'စီဘီဘဏ် (CB Bank)',
    bank_transfer: 'အခြားဘဏ်လွှဲပြောင်းမှု',
    mobile_wallet: 'မိုဘိုင်းပိုက်ဆံအိတ်',
    other: 'အခြားနည်းလမ်း',

    addExpense: 'လုပ်ငန်းစရိတ် အသစ်ထည့်ရန်',
    expenseCategory: 'အသုံးစရိတ်အမျိုးအစား',
    expenseAmount: 'စရိတ်ငွေပမာဏ',
    expenseDescription: 'အသုံးစရိတ်ဖော်ပြချက်',
    cashMovements: 'ငွေသားနှင့် ဘဏ်စာရင်း ရွေ့လျားမှု',
    bankDeposit: 'ငွေသားအား ဘဏ်သို့သွင်းခြင်း',
    bankWithdrawal: 'ဘဏ်မှ ငွေသားထုတ်ယူခြင်း',
    ownerCapital: 'လုပ်ငန်းရှင် မတည်ငွေထည့်ဝင်ခြင်း',
    ownerDrawing: 'လုပ်ငန်းရှင် ထုတ်ယူငွေ',
    recordMovement: 'စာရင်းမှတ်တမ်းတင်ရန်',

    reconciliationTitle: 'နေ့စဉ် ငွေစာရင်းချုပ်နှင့် လက်ကျန်ငွေစစ်ဆေးခြင်း',
    openingCashBalance: 'စတင်ချိန် လက်ကျန်ငွေ',
    expectedClosingCash: 'စာရင်းအရ ရှိရမည့် လက်ကျန်ငွေ',
    actualCountedCash: 'အမှန်တကယ် ရေတွက်ရရှိငွေ',
    cashVariance: 'ကွာခြားချက်',
    balanced: 'စာရင်းနှင့် အမှန်တကယ် တိကျစွာကိုက်ညီသည်',
    cashSurplus: 'ငွေပိုနေသည် (+ Extra Cash)',
    cashShortage: 'ငွေလိုနေသည် (- Missing Cash)',
    submitReconciliation: 'နေ့စဉ်စာရင်းချုပ်ပြီး သိမ်းဆည်းမည်',

    receiptTitle: 'တရားဝင် ငွေလွှဲပြေစာ (ဘောက်ချာ)',
    customerCopy: 'ငွေပို့သူမိတ္တူ',
    officeCopy: 'ရုံးလက်ခံမိတ္တူ',
    thermalReceipt: 'အပူသုံးဘောက်ချာ (80mm POS)',
    a4Receipt: 'ရုံးသုံး A4 စာရွက်ပုံစံ',
    authorizedSignature: 'တာဝန်ခံလက်မှတ်',
    customerSignature: 'ငွေပို့သူလက်မှတ်',
    thankYouMessage: 'ကျွန်ုပ်တို့၏ ငွေလွှဲဝန်ဆောင်မှုကို အသုံးပြုသည့်အတွက် ကျေးဇူးတင်ရှိပါသည်။',

    fiduciaryNotice: 'ဘဏ္ဍာရေးစာရင်းခွဲခြားမှု သတိပေးချက်',
    passThroughExpl: 'ဖောက်သည်များ၏ လွှဲပြောင်းငွေသည် ဖောက်သည်များ၏ ပိုင်ဆိုင်မှုဖြစ်ပြီး လုပ်ငန်း၏ တိုက်ရိုက်အမြတ်ငွေ မဟုတ်ပါ။',
    businessIncomeExpl: 'လုပ်ငန်း၏ တကယ့်ဝင်ငွေမှာ ဝန်ဆောင်ခ (Service Fees) သာဖြစ်ပြီး၊ လုပ်ငန်းစရိတ်များနုတ်ပြီးမှ အသားတင်အမြတ် ထွက်ပေါ်ပါသည်။',
    openingBalance: 'အဖွင့်လက်ကျန်',
    closingBalance: 'အပိတ်လက်ကျန်',
    netCashFlow: 'နေ့စဉ်ငွေသားစီးဆင်းမှု',

    businessProfile: 'လုပ်ငန်းအချက်အလက်နှင့် တံဆိပ်',
    companyName: 'လုပ်ငန်း/ကုမ္ပဏီအမည်',
    phone: 'ဖုန်းနံပါတ်',
    address: 'လိပ်စာ',
    licenseNo: 'ငွေလွှဲလုပ်ငန်း လိုင်စင်/မှတ်ပုံတင်နံပါတ်',
    userManagement: 'ဝန်ထမ်းများနှင့် ခွင့်ပြုချက်များ စီမံခန့်ခွဲမှု',
    backupAndRestore: 'ဒေတာ မိတ္တူကူးခြင်းနှင့် ပြန်လည်ရယူခြင်း',
    backupDownload: 'ဒေတာမိတ္တူ ဒေါင်းလုဒ်ယူရန် (JSON)',
    restoreUpload: 'ဒေတာမိတ္တူ ပြန်လည်ထည့်သွင်းရန် (JSON)',
    complianceNotice: 'ဥပဒေနှင့် စည်းမျဉ်းလိုက်နာမှု သတိပေးချက်',
    complianceWarning: 'ဤစနစ်သည် ငွေလွှဲလုပ်ငန်းစာရင်းများကို တိကျစွာမှတ်တမ်းတင်ရန် စီမံထားခြင်းဖြစ်ပါသည်။ တရားဝင်ငွေလွှဲလုပ်ငန်း လုပ်ကိုင်ရန် သက်ဆိုင်ရာဗဟိုဘဏ်နှင့် အစိုးရဌာနများ၏ လိုင်စင်နှင့် ဥပဒေစည်းမျဉ်းများကို လိုက်နာရန် လိုအပ်ပါသည်။'
  }
};

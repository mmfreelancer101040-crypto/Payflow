import { 
  MoneyTransfer, 
  BusinessExpense, 
  CashMovement, 
  CashReconciliation, 
  AuditLog, 
  User, 
  BusinessProfile,
  Currency 
} from '../types';

const STORAGE_KEYS = {
  TRANSFERS: 'swiftremit_transfers',
  EXPENSES: 'swiftremit_expenses',
  CASH_MOVEMENTS: 'swiftremit_cash_movements',
  RECONCILIATIONS: 'swiftremit_reconciliations',
  AUDIT_LOGS: 'swiftremit_audit_logs',
  USERS: 'swiftremit_users',
  CURRENT_USER: 'swiftremit_current_user',
  BUSINESS_PROFILE: 'swiftremit_profile',
  CURRENCIES: 'swiftremit_currencies',
  OPENING_CASH: 'swiftremit_opening_cash',
};

export const INITIAL_CURRENCIES: Currency[] = [
  { code: 'MMK', symbol: 'Ks', name: 'Myanmar Kyat', rateToBase: 1, decimals: 0 },
  { code: 'USD', symbol: '$', name: 'US Dollar', rateToBase: 3500, decimals: 2 },
  { code: 'THB', symbol: '฿', name: 'Thai Baht', rateToBase: 100, decimals: 2 },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', rateToBase: 2650, decimals: 2 },
  { code: 'MYR', symbol: 'RM', name: 'Malaysian Ringgit', rateToBase: 780, decimals: 2 },
];

export const INITIAL_USERS: User[] = [
  {
    id: 'USR-001',
    name: 'Daw Khin Sandar (Manager)',
    email: 'admin@swiftremit.com',
    role: 'admin',
    phone: '+95 9 798 112233',
    permissions: {
      canEditTransactions: true,
      canCancelOrRefund: true,
      canManageUsers: true,
      canViewAuditLogs: true,
      canManageCashReconciliation: true,
      canManageExpenses: true,
      canExportData: true,
    },
    isActive: true,
    createdAt: '2026-01-01T08:00:00Z',
  },
  {
    id: 'USR-002',
    name: 'Ko Min Thura (Teller)',
    email: 'staff@swiftremit.com',
    role: 'staff',
    phone: '+95 9 450 445566',
    permissions: {
      canEditTransactions: false,
      canCancelOrRefund: false,
      canManageUsers: false,
      canViewAuditLogs: false,
      canManageCashReconciliation: true,
      canManageExpenses: true,
      canExportData: false,
    },
    isActive: true,
    createdAt: '2026-02-15T09:00:00Z',
  },
];

export const INITIAL_BUSINESS_PROFILE: BusinessProfile = {
  name: 'SwiftRemit Money Transfer & Remittance Co., Ltd.',
  tagline: 'Reliable, Secure & Fast Domestic & International Remittance',
  address: 'No. 142/B, Bogyoke Aung San Road, Kyauktada Township, Yangon, Myanmar',
  phone: '+95 9 798 112233',
  secondaryPhone: '+95 1 245 890',
  email: 'support@swiftremit.com',
  licenseNumber: 'CBM-MTO-2024/0084',
  baseCurrency: 'MMK',
  logoUrl: '/src/assets/images/money_transfer_logo_1791888830641.jpg',
  receiptFooterNote: 'Please keep this receipt for transaction tracking and receiver collection verification.',
  receiptTerms: 'Recipients must provide valid National Registration Card (NRC) or Passport matching the designated receiver name. Inquiries must be made within 7 days.',
  taxNumber: 'TIN-40098231',
  branchName: 'Yangon Central Branch',
};

// Seed realistic demo data for initial load
function getInitialTransfers(): MoneyTransfer[] {
  const today = '2026-10-13';
  return [
    {
      id: 'TRF-20261013-0001',
      date: `${today}T08:30:00.000Z`,
      senderName: 'U Aung Kyaw',
      senderPhone: '09798543210',
      senderLocation: 'Yangon (Central)',
      receiverName: 'Daw Mya Mya',
      receiverPhone: '09450123456',
      receiverLocation: 'Mandalay (Chanayethazan)',
      sendAmount: 500000,
      sendCurrency: 'MMK',
      payoutAmount: 500000,
      payoutCurrency: 'MMK',
      exchangeRate: 1.0,
      serviceFee: 5000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 505000,
      amountToBePaidToReceiver: 500000,
      paymentMethod: 'cash',
      payoutMethod: 'cash',
      status: 'completed',
      handledByStaffName: 'Ko Min Thura (Teller)',
      handledByStaffId: 'USR-002',
      notes: 'Receiver will collect at Mandalay branch with NRC',
      createdAt: `${today}T08:30:00.000Z`,
      updatedAt: `${today}T08:30:00.000Z`,
    },
    {
      id: 'TRF-20261013-0002',
      date: `${today}T09:15:00.000Z`,
      senderName: 'Ma Hnin Ei',
      senderPhone: '09970889900',
      senderLocation: 'Yangon',
      receiverName: 'Ko Zaw Zaw',
      receiverPhone: '09250334455',
      receiverLocation: 'Taunggyi',
      sendAmount: 1200000,
      sendCurrency: 'MMK',
      payoutAmount: 1200000,
      payoutCurrency: 'MMK',
      exchangeRate: 1.0,
      serviceFee: 12000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 1212000,
      amountToBePaidToReceiver: 1200000,
      paymentMethod: 'kbz_pay',
      payoutMethod: 'cash',
      paymentReference: 'KPAY-994821',
      status: 'completed',
      handledByStaffName: 'Ko Min Thura (Teller)',
      handledByStaffId: 'USR-002',
      notes: 'Sender paid via KBZPay QR scan at counter',
      createdAt: `${today}T09:15:00.000Z`,
      updatedAt: `${today}T09:15:00.000Z`,
    },
    {
      id: 'TRF-20261013-0003',
      date: `${today}T10:00:00.000Z`,
      senderName: 'Daw San San Aye',
      senderPhone: '09790112233',
      senderLocation: 'Yangon',
      receiverName: 'Ma Thidar Win',
      receiverPhone: '+66 81 234 5678',
      receiverLocation: 'Bangkok, Thailand',
      sendAmount: 3500000,
      sendCurrency: 'MMK',
      payoutAmount: 35000,
      payoutCurrency: 'THB',
      exchangeRate: 0.01,
      serviceFee: 25000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 3525000,
      amountToBePaidToReceiver: 35000,
      paymentMethod: 'cash',
      payoutMethod: 'bank_transfer',
      payoutReference: 'PromptPay / Kasikorn Bank',
      status: 'processing',
      handledByStaffName: 'Daw Khin Sandar (Manager)',
      handledByStaffId: 'USR-001',
      notes: 'Overseas transfer to student in Bangkok',
      createdAt: `${today}T10:00:00.000Z`,
      updatedAt: `${today}T10:00:00.000Z`,
    },
    {
      id: 'TRF-20261013-0004',
      date: `${today}T10:45:00.000Z`,
      senderName: 'U Than Naing',
      senderPhone: '09443322110',
      senderLocation: 'Yangon',
      receiverName: 'Ko Thet Naing',
      receiverPhone: '09965544332',
      receiverLocation: 'Naypyidaw',
      sendAmount: 800000,
      sendCurrency: 'MMK',
      payoutAmount: 800000,
      payoutCurrency: 'MMK',
      exchangeRate: 1.0,
      serviceFee: 8000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 808000,
      amountToBePaidToReceiver: 800000,
      paymentMethod: 'cash',
      payoutMethod: 'wave_pay',
      status: 'pending',
      handledByStaffName: 'Ko Min Thura (Teller)',
      handledByStaffId: 'USR-002',
      notes: 'Awaiting cash deposit verification into WavePay agent wallet',
      createdAt: `${today}T10:45:00.000Z`,
      updatedAt: `${today}T10:45:00.000Z`,
    },
    {
      id: 'TRF-20261012-0001',
      date: `2026-10-12T09:00:00.000Z`,
      senderName: 'U Tin Aung',
      senderPhone: '09781234567',
      senderLocation: 'Yangon',
      receiverName: 'Daw Cho Cho',
      receiverPhone: '09420098765',
      receiverLocation: 'Pyin Oo Lwin',
      sendAmount: 1500000,
      sendCurrency: 'MMK',
      payoutAmount: 1500000,
      payoutCurrency: 'MMK',
      exchangeRate: 1.0,
      serviceFee: 15000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 1515000,
      amountToBePaidToReceiver: 1500000,
      paymentMethod: 'cash',
      payoutMethod: 'cash',
      status: 'completed',
      handledByStaffName: 'Ko Min Thura (Teller)',
      handledByStaffId: 'USR-002',
      notes: 'Yesterday cash transaction completed smoothly',
      createdAt: `2026-10-12T09:00:00.000Z`,
      updatedAt: `2026-10-12T09:00:00.000Z`,
    },
    {
      id: 'TRF-20261011-0001',
      date: `2026-10-11T11:20:00.000Z`,
      senderName: 'Daw Khin Aye',
      senderPhone: '09955112233',
      senderLocation: 'Yangon',
      receiverName: 'U Soe Win',
      receiverPhone: '09433221199',
      receiverLocation: 'Mawlamyine',
      sendAmount: 400000,
      sendCurrency: 'MMK',
      payoutAmount: 400000,
      payoutCurrency: 'MMK',
      exchangeRate: 1.0,
      serviceFee: 4000,
      feePaymentMode: 'sender_pays_extra',
      totalCollectedFromSender: 404000,
      amountToBePaidToReceiver: 400000,
      paymentMethod: 'cash',
      payoutMethod: 'cash',
      status: 'refunded',
      refundStatus: 'full',
      refundAmount: 404000,
      refundFeeRetained: 0,
      refundReason: 'Sender requested cancellation prior to payout due to wrong receiver phone number',
      refundedAt: `2026-10-11T12:00:00.000Z`,
      refundedByStaffName: 'Daw Khin Sandar (Manager)',
      handledByStaffName: 'Ko Min Thura (Teller)',
      handledByStaffId: 'USR-002',
      notes: 'Full refund handed in cash to sender with signature',
      createdAt: `2026-10-11T11:20:00.000Z`,
      updatedAt: `2026-10-11T12:00:00.000Z`,
    }
  ];
}

function getInitialExpenses(): BusinessExpense[] {
  const today = '2026-10-13';
  return [
    {
      id: 'EXP-20261013-0001',
      date: `${today}T09:30:00.000Z`,
      category: 'office_supplies',
      amount: 15000,
      currency: 'MMK',
      paymentMethod: 'cash',
      description: 'Thermal receipt paper rolls (20 rolls pack) and pens',
      recordedByStaffName: 'Ko Min Thura (Teller)',
      recordedByStaffId: 'USR-002',
      receiptNumber: 'RCP-0982',
      createdAt: `${today}T09:30:00.000Z`,
    },
    {
      id: 'EXP-20261013-0002',
      date: `${today}T11:00:00.000Z`,
      category: 'refreshments',
      amount: 6000,
      currency: 'MMK',
      paymentMethod: 'cash',
      description: 'Drinking water dispenser 20L bottles for customer lobby',
      recordedByStaffName: 'Ko Min Thura (Teller)',
      recordedByStaffId: 'USR-002',
      receiptNumber: 'WAT-441',
      createdAt: `${today}T11:00:00.000Z`,
    },
    {
      id: 'EXP-20261010-0001',
      date: '2026-10-10T14:00:00.000Z',
      category: 'internet_phone',
      amount: 45000,
      currency: 'MMK',
      paymentMethod: 'kbz_pay',
      description: 'Monthly Fiber Internet connection for branch counter',
      recordedByStaffName: 'Daw Khin Sandar (Manager)',
      recordedByStaffId: 'USR-001',
      receiptNumber: 'INV-FIBER-1026',
      createdAt: '2026-10-10T14:00:00.000Z',
    }
  ];
}

function getInitialMovements(): CashMovement[] {
  return [
    {
      id: 'MOV-20261013-0001',
      date: '2026-10-13T08:00:00.000Z',
      type: 'owner_capital_in',
      amount: 2000000,
      currency: 'MMK',
      bankAccountOrSource: 'Branch Float Register Injection',
      referenceNumber: 'FLOAT-1013',
      description: 'Opening register float cash for daily branch operations',
      recordedByStaffName: 'Daw Khin Sandar (Manager)',
      createdAt: '2026-10-13T08:00:00.000Z',
    }
  ];
}

function getInitialReconciliations(): CashReconciliation[] {
  return [
    {
      id: 'REC-20261012',
      date: '2026-10-12',
      openingBalance: 1500000,
      cashReceivedToday: 1515000,
      cashPaidOutToday: 1500000,
      cashFeesReceivedToday: 15000,
      cashExpensesPaidToday: 0,
      bankDepositsFromCash: 0,
      bankWithdrawalsToCash: 0,
      expectedClosingCash: 1515000,
      actualCountedCash: 1515000,
      variance: 0,
      notes: 'End of day register checked and verified. All cash matched exactly.',
      reconciledByStaffName: 'Daw Khin Sandar (Manager)',
      createdAt: '2026-10-12T17:30:00.000Z',
    }
  ];
}

function getInitialAuditLogs(): AuditLog[] {
  return [
    {
      id: 'AUD-001',
      timestamp: '2026-10-13T08:00:00.000Z',
      userId: 'USR-001',
      userName: 'Daw Khin Sandar (Manager)',
      action: 'LOGIN',
      entityType: 'auth',
      entityId: 'USR-001',
      details: 'Admin user logged in and opened morning branch session',
    },
    {
      id: 'AUD-002',
      timestamp: '2026-10-13T08:30:00.000Z',
      userId: 'USR-002',
      userName: 'Ko Min Thura (Teller)',
      action: 'CREATE',
      entityType: 'transfer',
      entityId: 'TRF-20261013-0001',
      details: 'Recorded new money transfer: 500,000 MMK from U Aung Kyaw to Daw Mya Mya',
    }
  ];
}

export class StorageService {
  static getTransfers(): MoneyTransfer[] {
    const data = localStorage.getItem(STORAGE_KEYS.TRANSFERS);
    if (!data) {
      const initial = getInitialTransfers();
      this.saveAllTransfers(initial);
      return initial;
    }
    try {
      return JSON.parse(data);
    } catch {
      return getInitialTransfers();
    }
  }

  static saveAllTransfers(transfers: MoneyTransfer[]): void {
    localStorage.setItem(STORAGE_KEYS.TRANSFERS, JSON.stringify(transfers));
  }

  static addTransfer(transfer: MoneyTransfer, user: User): void {
    const list = this.getTransfers();
    list.unshift(transfer);
    this.saveAllTransfers(list);

    this.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      action: 'CREATE',
      entityType: 'transfer',
      entityId: transfer.id,
      details: `Created transfer of ${transfer.sendAmount} ${transfer.sendCurrency} to ${transfer.receiverName} (${transfer.receiverLocation})`,
    });
  }

  static updateTransfer(updated: MoneyTransfer, user: User, reason?: string): void {
    const list = this.getTransfers();
    const idx = list.findIndex(t => t.id === updated.id);
    if (idx !== -1) {
      list[idx] = {
        ...updated,
        updatedAt: new Date().toISOString(),
        updatedByStaffName: user.name,
      };
      this.saveAllTransfers(list);

      this.addAuditLog({
        id: `AUD-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user.id,
        userName: user.name,
        action: 'UPDATE',
        entityType: 'transfer',
        entityId: updated.id,
        details: `Updated transfer details. Reason: ${reason || 'Customer requested update'}`,
      });
    }
  }

  static cancelTransfer(id: string, reason: string, user: User): void {
    const list = this.getTransfers();
    const idx = list.findIndex(t => t.id === id);
    if (idx !== -1) {
      const t = list[idx];
      list[idx] = {
        ...t,
        status: 'cancelled',
        cancellationReason: reason,
        cancelledAt: new Date().toISOString(),
        cancelledByStaffName: user.name,
        cancelledByStaffId: user.id,
        updatedAt: new Date().toISOString(),
      };
      this.saveAllTransfers(list);

      this.addAuditLog({
        id: `AUD-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user.id,
        userName: user.name,
        action: 'CANCEL',
        entityType: 'transfer',
        entityId: id,
        details: `Cancelled transaction ${id}. Reason: ${reason}`,
      });
    }
  }

  static refundTransfer(
    id: string, 
    refundAmount: number, 
    retainedFee: number, 
    reason: string, 
    user: User
  ): void {
    const list = this.getTransfers();
    const idx = list.findIndex(t => t.id === id);
    if (idx !== -1) {
      const t = list[idx];
      list[idx] = {
        ...t,
        status: 'refunded',
        refundStatus: 'full',
        refundAmount,
        refundFeeRetained: retainedFee,
        refundReason: reason,
        refundedAt: new Date().toISOString(),
        refundedByStaffName: user.name,
        updatedAt: new Date().toISOString(),
      };
      this.saveAllTransfers(list);

      this.addAuditLog({
        id: `AUD-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user.id,
        userName: user.name,
        action: 'REFUND',
        entityType: 'transfer',
        entityId: id,
        details: `Processed refund of ${refundAmount} (Fee retained: ${retainedFee}). Reason: ${reason}`,
      });
    }
  }

  static getExpenses(): BusinessExpense[] {
    const data = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    if (!data) {
      const initial = getInitialExpenses();
      this.saveAllExpenses(initial);
      return initial;
    }
    try {
      return JSON.parse(data);
    } catch {
      return getInitialExpenses();
    }
  }

  static saveAllExpenses(expenses: BusinessExpense[]): void {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
  }

  static addExpense(expense: BusinessExpense, user: User): void {
    const list = this.getExpenses();
    list.unshift(expense);
    this.saveAllExpenses(list);

    this.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      action: 'EXPENSE',
      entityType: 'expense',
      entityId: expense.id,
      details: `Recorded business expense: ${expense.amount} ${expense.currency} for [${expense.category}] - ${expense.description}`,
    });
  }

  static getCashMovements(): CashMovement[] {
    const data = localStorage.getItem(STORAGE_KEYS.CASH_MOVEMENTS);
    if (!data) {
      const initial = getInitialMovements();
      this.saveAllMovements(initial);
      return initial;
    }
    try {
      return JSON.parse(data);
    } catch {
      return getInitialMovements();
    }
  }

  static saveAllMovements(movements: CashMovement[]): void {
    localStorage.setItem(STORAGE_KEYS.CASH_MOVEMENTS, JSON.stringify(movements));
  }

  static addCashMovement(movement: CashMovement, user: User): void {
    const list = this.getCashMovements();
    list.unshift(movement);
    this.saveAllMovements(list);

    this.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      action: 'UPDATE',
      entityType: 'reconciliation',
      entityId: movement.id,
      details: `Recorded cash movement: ${movement.type} of ${movement.amount} ${movement.currency} (${movement.bankAccountOrSource})`,
    });
  }

  static getReconciliations(): CashReconciliation[] {
    const data = localStorage.getItem(STORAGE_KEYS.RECONCILIATIONS);
    if (!data) {
      const initial = getInitialReconciliations();
      this.saveAllReconciliations(initial);
      return initial;
    }
    try {
      return JSON.parse(data);
    } catch {
      return getInitialReconciliations();
    }
  }

  static saveAllReconciliations(reconciliations: CashReconciliation[]): void {
    localStorage.setItem(STORAGE_KEYS.RECONCILIATIONS, JSON.stringify(reconciliations));
  }

  static addReconciliation(rec: CashReconciliation, user: User): void {
    const list = this.getReconciliations();
    const existingIdx = list.findIndex(r => r.date === rec.date);
    if (existingIdx !== -1) {
      list[existingIdx] = rec;
    } else {
      list.unshift(rec);
    }
    this.saveAllReconciliations(list);

    this.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      action: 'RECONCILIATION',
      entityType: 'reconciliation',
      entityId: rec.id,
      details: `Completed cash close for ${rec.date}: Counted=${rec.actualCountedCash}, Expected=${rec.expectedClosingCash}, Variance=${rec.variance}`,
    });
  }

  static getAuditLogs(): AuditLog[] {
    const data = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    if (!data) {
      const initial = getInitialAuditLogs();
      this.saveAllAuditLogs(initial);
      return initial;
    }
    try {
      return JSON.parse(data);
    } catch {
      return getInitialAuditLogs();
    }
  }

  static saveAllAuditLogs(logs: AuditLog[]): void {
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs.slice(0, 500))); // keep latest 500
  }

  static addAuditLog(log: AuditLog): void {
    const logs = this.getAuditLogs();
    logs.unshift(log);
    this.saveAllAuditLogs(logs);
  }

  static getUsers(): User[] {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!data) {
      this.saveAllUsers(INITIAL_USERS);
      return INITIAL_USERS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_USERS;
    }
  }

  static saveAllUsers(users: User[]): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }

  static getCurrentUser(): User {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (data) {
      try {
        return JSON.parse(data);
      } catch {
        // fallback
      }
    }
    // Default to admin user for convenient start
    const admin = INITIAL_USERS[0];
    this.setCurrentUser(admin);
    return admin;
  }

  static setCurrentUser(user: User | null): void {
    if (!user) {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    } else {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    }
  }

  static getBusinessProfile(): BusinessProfile {
    const data = localStorage.getItem(STORAGE_KEYS.BUSINESS_PROFILE);
    if (!data) {
      this.saveBusinessProfile(INITIAL_BUSINESS_PROFILE);
      return INITIAL_BUSINESS_PROFILE;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_BUSINESS_PROFILE;
    }
  }

  static saveBusinessProfile(profile: BusinessProfile): void {
    localStorage.setItem(STORAGE_KEYS.BUSINESS_PROFILE, JSON.stringify(profile));
  }

  static getCurrencies(): Currency[] {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENCIES);
    if (!data) {
      this.saveCurrencies(INITIAL_CURRENCIES);
      return INITIAL_CURRENCIES;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_CURRENCIES;
    }
  }

  static saveCurrencies(currencies: Currency[]): void {
    localStorage.setItem(STORAGE_KEYS.CURRENCIES, JSON.stringify(currencies));
  }

  static getOpeningCash(): number {
    const data = localStorage.getItem(STORAGE_KEYS.OPENING_CASH);
    if (!data) return 2000000; // 2 million MMK initial opening float
    return parseFloat(data) || 0;
  }

  static setOpeningCash(val: number): void {
    localStorage.setItem(STORAGE_KEYS.OPENING_CASH, val.toString());
  }

  // Backup & Restore
  static exportFullBackup(): string {
    const payload = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      profile: this.getBusinessProfile(),
      users: this.getUsers(),
      currencies: this.getCurrencies(),
      transfers: this.getTransfers(),
      expenses: this.getExpenses(),
      cashMovements: this.getCashMovements(),
      reconciliations: this.getReconciliations(),
      auditLogs: this.getAuditLogs(),
      openingCash: this.getOpeningCash(),
    };
    return JSON.stringify(payload, null, 2);
  }

  static importFullBackup(jsonString: string, currentUser: User): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.transfers || !Array.isArray(parsed.transfers)) {
        throw new Error('Invalid backup schema');
      }

      if (parsed.profile) this.saveBusinessProfile(parsed.profile);
      if (parsed.users) this.saveAllUsers(parsed.users);
      if (parsed.currencies) this.saveCurrencies(parsed.currencies);
      if (parsed.transfers) this.saveAllTransfers(parsed.transfers);
      if (parsed.expenses) this.saveAllExpenses(parsed.expenses);
      if (parsed.cashMovements) this.saveAllMovements(parsed.cashMovements);
      if (parsed.reconciliations) this.saveAllReconciliations(parsed.reconciliations);
      if (parsed.openingCash !== undefined) this.setOpeningCash(parsed.openingCash);

      this.addAuditLog({
        id: `AUD-${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userName: currentUser.name,
        action: 'RESTORE',
        entityType: 'settings',
        entityId: 'SYSTEM',
        details: `Restored database backup containing ${parsed.transfers.length} transfers and ${parsed.expenses?.length || 0} expenses`,
      });

      return true;
    } catch (err) {
      console.error('Backup import error:', err);
      return false;
    }
  }

  static resetToDemoData(currentUser: User): void {
    this.saveAllTransfers(getInitialTransfers());
    this.saveAllExpenses(getInitialExpenses());
    this.saveAllMovements(getInitialMovements());
    this.saveAllReconciliations(getInitialReconciliations());
    this.saveBusinessProfile(INITIAL_BUSINESS_PROFILE);
    this.saveCurrencies(INITIAL_CURRENCIES);
    this.setOpeningCash(2000000);

    this.addAuditLog({
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'settings',
      entityId: 'SYSTEM',
      details: 'Reset application database to pristine demo data state',
    });
  }

  static generateNewTransactionId(): string {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const datePrefix = `TRF-${y}${m}${d}`;
    
    const transfers = this.getTransfers();
    const todayTransfers = transfers.filter(t => t.id.startsWith(datePrefix));
    const nextNum = todayTransfers.length + 1;
    return `${datePrefix}-${String(nextNum).padStart(4, '0')}`;
  }

  static generateNewExpenseId(): string {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const datePrefix = `EXP-${y}${m}${d}`;

    const expenses = this.getExpenses();
    const todayExpenses = expenses.filter(e => e.id.startsWith(datePrefix));
    const nextNum = todayExpenses.length + 1;
    return `${datePrefix}-${String(nextNum).padStart(4, '0')}`;
  }
}
